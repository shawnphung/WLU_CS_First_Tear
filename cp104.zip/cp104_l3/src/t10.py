"""
------------------------------------------------------------------------
[Takes in int's for day, month and year, and outputs said date in the yyyy/mm/dd format]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
year = int(input("Enter a year: "))
month = int(input("Enter a month: "))
day = int(input("Enter a day: "))

"Output"
print(f"The date: {year}/{month:02d}/{day:02d}")
