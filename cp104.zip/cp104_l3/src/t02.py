"""
------------------------------------------------------------------------
[Print multiple print functions to output Twinkle Twinkle Little Star]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
print("'Twinkle Twinkle Little Star' by Jane Taylor")
print("")
print("Twinkle, twinkle, little star,")
print("    How I wonder what you are!")
print("        Up above the world so high")
print("            Like a diamond in the sky!")
print("Twinkle, twinkle, little star,")
print("    How I wonder what you are!")
