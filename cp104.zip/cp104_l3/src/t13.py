"""
------------------------------------------------------------------------
[Takes in a number of seconds, calculates/outputs the number of hours, minutes and seconds as integers]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
secondIn = int(input("Enter number of seconds: "))

"Calculations"
hour = secondIn // 3600
secondOut = secondIn % 3600

minute = secondOut // 60
secondOut = secondOut % 60

"Output"
print(
    f"There are {hour} hours, {minute} minutes, and {secondOut} seconds in {secondIn} seconds.")
