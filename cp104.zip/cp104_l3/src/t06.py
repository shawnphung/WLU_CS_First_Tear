"""
------------------------------------------------------------------------
[Takes in price and quantity, prints them and calculates the total price]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
cost = float(input("Enter cost: "))
num = int(input("Enter quantity: "))

"Calculate total cost"
total = cost * num

"Output"
print(
    f"Given a total cost of ${cost:.2f} and a quantity of {num} the total is ${total:.2f}")
