"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
integer = 654321
decimal = 654.321
phrase = "Hello World"

"Output integer"
print(f"{integer:d}")
print(f"{integer:f}")
# print(f"{integer:s}")

"Output decimal"
# print(f"{decimal:d}")
print(f"{decimal:f}")
# print(f"{decimal:s}")

"Output string"
# print(f"{phrase:d}")
# print(f"{phrase:f}")
print(f"{phrase:s}")
