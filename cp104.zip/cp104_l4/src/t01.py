"""
------------------------------------------------------------------------
[Calculates the diemater of a circle, given the radius]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-12"
------------------------------------------------------------------------
"""
# Import
from functions import diameter

# Define variable
radius = float(input("Enter radius: "))

# Call function
diam = diameter(radius)

# Output
print()
print(f"Diameter of circle: {diam:.2f}")
