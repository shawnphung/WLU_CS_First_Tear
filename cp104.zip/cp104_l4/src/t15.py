"""
------------------------------------------------------------------------
[Converts a total number of seconds in days, hours, minutes and seconds]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-06"
------------------------------------------------------------------------
"""
# Import
from functions import time_split
sec = int(input("Number of seconds: "))

# Call function
day, hour, minute, second = time_split(sec)

# Output
print()
print(f"Days: {day}, Hours: {hour}, Minutes: {minute}, Seconds: {second}")
