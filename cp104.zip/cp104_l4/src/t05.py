"""
------------------------------------------------------------------------
[Given the lengths of the adjecent and opposite sides of a triangle, calculate and output hypotenuse, circumference and area]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-06"
------------------------------------------------------------------------
"""
# Import
from functions import right_triangle

# Define variables
adjacent = float(input("Length of adjacent side: "))
opposite = float(input("Length of opposite side: "))

# Call function
hyp, circ, area = right_triangle(adjacent, opposite)

# Output
print()
print(f"Hypotenuse of triangle: {hyp:.2f}")
print(f"Circumference of triangle: {circ:.2f}")
print(f"Area of triangle: {area:.2f}")
