"""
------------------------------------------------------------------------
[Converts temperature from celsius to fahrenheit]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-06"
------------------------------------------------------------------------
"""
# Import
from functions import c_to_f

# Define variable
celsius = int(input("Enter a temperature (c): "))

# Call function
fahr = c_to_f(celsius)

# Output
print()
print(f"{celsius} C = {fahr:.0f} F")
