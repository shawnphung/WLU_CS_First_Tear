"""
------------------------------------------------------------------------
[Calculates and returns radius, diameter, circumference and area of a circle using 2 sides of a right triangle]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-06"
------------------------------------------------------------------------
"""
# Import
from functions import pythag

# Define variables
s1 = float(input("Length of side 1: "))
s2 = float(input("Length of side 2: "))

# Call function
radius, diam, circ, area = pythag(s1, s2)

# Output
print()
print(f"Radius of resulting circle: {radius:.2f}")
print(f"Diameter of resulting circle: {diam:.2f}")
print(f"Circumference of resulting circle: {circ:.2f}")
print(f"Area of resulting circle: {area:.2f}")
