"""
------------------------------------------------------------------------
[Contains different functions to be called]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-06"
------------------------------------------------------------------------
"""
# Import
from math import sqrt
from math import pi

# function diameter


def diameter(radius):
    """
    -------------------------------------------------------
    Calculates and returns diameter of a circle.
    Use: diam = diameter(radius)
    -------------------------------------------------------
    Parameters:
        radius - radius of a circle (float >= 0)
    Returns:
        diam - diameter of a circle (float)
    ------------------------------------------------------
    """
    diam = radius * 2
    return diam

# function square pyramid


def square_pyramid(base, height):
    """
    -------------------------------------------------------
    Calculates and returns the slant height, area, and
    volume of a square pyramid given the base and perpendicular
    height.
    Use: sh, area, vol = square_pyramid(base, height)
    -------------------------------------------------------
    Parameters:
        base - length of the base of the pyramid (float > 0)
        height - perpendicular height of the pyramid (float > 0)
    Returns:
        sh - slant height of the square pyramid (float)
        area - area of the square pyramid (float)
        vol - volume of the square pyramid (float)
    ------------------------------------------------------
    """
    sh = sqrt(((base / 2) ** 2) + (height ** 2))
    area = (base ** 2) + (2 * base * sqrt(((base ** 2) / 4) + height ** 2))
    vol = (base ** 2) * (height / 3)
    return sh, area, vol

# function right triangle


def right_triangle(adjacent, opposite):
    """
    -------------------------------------------------------
    Calculates and returns the hypotenuse, circumference, and
    area of a right triangle given two non-hypotenuse sides.
    Use: hyp, circ, area = right_triangle(adjacent, opposite)
    -------------------------------------------------------
    Parameters:
        adjacent - length of side right triangle (float > 0)
        opposite - length of side right triangle (float > 0)
    Returns:
        hyp - hypotenuse of the triangle (float)
        circ - circumference of the triangle (float)
        area - area of the triangle (float)
    ------------------------------------------------------
    """
    hyp = sqrt((adjacent ** 2) + (opposite ** 2))
    circ = hyp + adjacent + opposite
    area = adjacent * opposite / 2
    return hyp, circ, area

# function pythag


def pythag(s1, s2):
    """
    -------------------------------------------------------
    Calculates and returns the radius, diameter, circumference,
    and area of circle defined by a right triangle.
    Use: radius, diam, circ, area = pythag(s1, s2)
    -------------------------------------------------------
    Parameters:
        s1 - length of side 1 of a right triangle (float > 0)
        s2 - length of side 2 of a right triangle (float > 0)
    Returns:
        radius - radius of the resulting circle (float)
        diam - diameter of the resulting circle (float)
        circ - circumference of the resulting circle (float)
        area - area of the resulting circle (float)
    ------------------------------------------------------
    """
    radius = sqrt((s1 ** 2) + (s2 ** 2))
    diam = radius * 2
    circ = 2 * pi * radius
    area = pi * (radius ** 2)
    return radius, diam, circ, area

# funtion celcius to fahrenheit


def c_to_f(celsius):
    """
    -------------------------------------------------------
    Converts temperatures in celsius to fahrenheit.
    Use: fahrenheit = c_to_f(celsius)
    -------------------------------------------------------
    Parameters:
        celsius - temperature in celsius (int >= -273)
    Returns:
        fahrenheit - equivalent to celsius (float)
    -------------------------------------------------------
    """
    FREEZING = 32
    fahrenheit = (9 / 5) * celsius + FREEZING
    return fahrenheit

# function time split


def time_split(initial_seconds):
    """
    -------------------------------------------------------
    Converts total seconds into days, hours, minutes, and seconds.
    Use: days, hours, minutes, seconds = time_split(initial_seconds)
    -------------------------------------------------------
    Parameters:
        initial_seconds - time elapsed (int >= 0)
    Returns:
        days - number of days in initial_seconds (int)
        hours - remaining hours in initial_seconds (int)
        minutes - remaining minutes in initial_seconds (int)
        seconds - remaining seconds in initial_seconds (int)
    -------------------------------------------------------
    """
    # Constants
    SECDAY = 86400
    SECHOUR = 3600
    SECMIN = 60

    DAYS = initial_seconds // SECDAY
    HOURS = (initial_seconds % SECDAY) // SECHOUR
    MINUTES = (initial_seconds % SECHOUR) // SECMIN
    SECONDS = initial_seconds % SECMIN
    return DAYS, HOURS, MINUTES, SECONDS
