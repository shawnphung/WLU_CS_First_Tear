"""
------------------------------------------------------------------------
[Given the base length and perpendicular height of a pyramid, program calculates and outputs the: slant height, area and volume of the square pyramid]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-06"
------------------------------------------------------------------------
"""
# Import
from functions import square_pyramid

# Define variables
base = float(input("Length of base: "))
height = float(input("Perpendicular height of pyramid: "))

# Call function
sh, area, vol = square_pyramid(base, height)

# Output
print()
print(f"Slant height of square pyramid: {sh:.2f}")
print(f"Area of square pyramid: {area:.2f}")
print(f"Volume of square pyramid: {vol:.2f}")
