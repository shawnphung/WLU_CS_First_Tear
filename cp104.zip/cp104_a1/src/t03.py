"""
------------------------------------------------------------------------
[Converts miles to km and prints it]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
CONVERSION = 1.609
mi = float(input("Length in miles: "))

"Calculations"
km = mi * CONVERSION

print("Length in km: ", km)
