"""
------------------------------------------------------------------------
[User input age and fav. band; output their age and fav. band in a sentence]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
age = int(input("Enter your age: "))
band = input("Enter your favourite band: ")

"Output"
print(f"I am {age} years old and my favourite band is {band}")
