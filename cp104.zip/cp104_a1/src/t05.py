"""
------------------------------------------------------------------------
[Calculates compound interest]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
principal = float(input("Principal: "))
interest = float(input("Interest (decimal): "))
year = int(input("Number of years: "))
num = int(input("Number of times interest compounded per year: "))

"Calculations"
balance = principal * ((1 + (interest / num)) ** (num * year))

"Output"
print(f"Balance: ${balance:.2f}")
