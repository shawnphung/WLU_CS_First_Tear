"""
------------------------------------------------------------------------
[Outputs 4 different print functions using different type of quotations]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
print('The book title is, "The Fifth Season."')
print("What's mine is mine, and what's yours is mine")
print('''"Experience is one thing you can't get for nothing." Oscar Wilde''')
print("""Three things that cannot be long hidden:
the sun,
the moon,
and the truth.""")
