"""
------------------------------------------------------------------------
[Calculates total price of x amount of burritos for x price]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
cost = float(input("Cost of 1 burrito: $"))
num = int(input("Number of burritos: "))

"Calculations"
total = cost * num

"Output"
print(f"Total cost of {num} burritos: ${total:.2f}")
