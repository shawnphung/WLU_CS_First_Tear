"""
------------------------------------------------------------------------
[Converts a list of characters into a matrix of their values]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-01"
------------------------------------------------------------------------
"""
# Import
from functions import words_to_matrix

# Declare list
word_list = ['h', 'el', 'lo', 'world']

# Call function
matrix = words_to_matrix(word_list)

# Output
print(matrix)
