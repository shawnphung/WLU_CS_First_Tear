"""
------------------------------------------------------------------------
[Holds functions to be called ]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-01"
------------------------------------------------------------------------
"""
# Import
import random
import string

# Generate character matrix function


def generate_matrix_char(rows, cols):
    """
    -------------------------------------------------------
    Generates a 2D list of random lower case letter ('a' - 'z') values
    Use: matrix = generate_matrix_char(rows, cols)
    -------------------------------------------------------
    Parameters:
        rows - number of rows in the generated matrix (int > 0)
        cols - number of columns in the generated matrix (int > 0)
    Returns:
        matrix - a 2D list of random characters (2D list of str)
    -------------------------------------------------------
    """
    matrix = []

    for i in range(rows):
        letters = []
        for u in range(cols):
            letter = random.choice(string.ascii_letters).lower()
            letters.append(letter)
        matrix.append(letters)

    return matrix


# Print character matrix function
def print_matrix_char(matrix):
    """
    -------------------------------------------------------
    Prints the contents of a 2D list of strings in a formatted table.
    Prints row and column headings.
    Use: print_matrix_char(matrix)
    -------------------------------------------------------
    Parameters:
        matrix - a 2D list of strings (2D list)
    Returns:
        None.
    -------------------------------------------------------
    """
    print(f"         0", end="")
    for i in range(1, len(matrix[0])):
        print(f"    {i}", end="")
    print()
    for i in range(len(matrix)):
        print(f"    {i}", end="")
        for u in matrix[i]:
            print(f"    {u}", end="")
        print()

    return


# Words to matrix function
def words_to_matrix(word_list):
    """
    -------------------------------------------------------
    Generates a 2D list of character values from the given
    list of words. All words must be the same length.
    Use: matrix = words_to_matrix(word_list)
    -------------------------------------------------------
    Parameters:
        word_list - a list containing the words to be placed in
            the matrix (list of string)
    Returns:
        matrix - a 2D list of characters of the given words
         in word_list (2D list of string).
    -------------------------------------------------------
    """
    matrix = []
    for i in word_list:
        temp = []
        for u in i:
            temp.append(u)
        matrix.append(temp)
    return matrix


# Count frequency function
def count_frequency(matrix, char):
    """
    -------------------------------------------------------
    Count the number of appearances of the given character char
    in matrix.
    Use: count = count_frequency(matrix, char)
    -------------------------------------------------------
    Parameters:
        matrix - the matrix to search in it (2D list of str)
        char - character to search for it (str, len = 1)
    Returns:
        count - the number of appearances of char in the matrix (int)
    -------------------------------------------------------
    """
    count = 0

    for i in range(len(matrix)):
        for u in matrix[i]:
            if u == char:
                count += 1
    return count


# Diagonal word search function
def find_word_diagonal(matrix, word):
    """
    -------------------------------------------------------
    Returns whether word is on the diagonal of a square matrix
    of characters.
    Use: found = find_word_diagonal(matrix, word)
    -------------------------------------------------------
    Parameters:
        matrix - a 2d list of characters (2d list of str)
        word - the word to compare against the diagonal of matrix (str)
    Returns:
        found - True if word is on the diagonal of matrix,
            False otherwise (boolean)
    ------------------------------------------------------
    """
    found = False
    diagonal = ''

    for i in range(len(matrix)):
        diagonal += matrix[i][i]
    if diagonal == word:
        found = True

    return found
