"""
------------------------------------------------------------------------
[Generates matrix of characters given number of rows and columns]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-01"
------------------------------------------------------------------------
"""
# Import
from functions import generate_matrix_char

# Declare variables
rows = int(input("Enter number of rows: "))
cols = int(input("Enter number of columns: "))

# Call function
matrix = generate_matrix_char(rows, cols)

# Output
print()
print("Matrix of characters:")
print()
print(matrix)
