"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-01"
------------------------------------------------------------------------
"""
# Imports
from functions import find_word_diagonal

# Define variables
matrix = ['cat', 'dog', 'big']
print(matrix)
word = input("Enter word to search for: ")

# Call function
found = find_word_diagonal(matrix, word)

# Output
if found == True:
    print(f"The word '{word}' is found on the diagonal.")
else:
    print(f"The word '{word}' is not found on the diagonal.")
