"""
------------------------------------------------------------------------
[Returns the number of times a character shows up in a matrix]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-01"
------------------------------------------------------------------------
"""
# Import
from functions import count_frequency
from functions import generate_matrix_char

# Declare variables
row = int(input("Number of rows: "))
cols = int(input("Number of columns: "))

# Call functions / output
matrix = generate_matrix_char(row, cols)
print()
print(f"Matrix of characters: {matrix}")
print()
char = input("Enter the character to search for: ")
count = count_frequency(matrix, char)
print(f"Character {char} appears {count} times in the matrix")
