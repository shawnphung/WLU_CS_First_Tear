"""
------------------------------------------------------------------------
[Prints a table of the given character matrix]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-01"
------------------------------------------------------------------------
"""
# Imports
from functions import print_matrix_char
from functions import generate_matrix_char

# Declare variables
row = int(input("Number of rows: "))
cols = int(input("Number of columns: "))

# Call functions / output
print()
matrix = generate_matrix_char(row, cols)
print_matrix_char(matrix)
