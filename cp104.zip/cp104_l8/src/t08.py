"""
------------------------------------------------------------------------
[Returns a value's index in a list]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-11"
------------------------------------------------------------------------
"""
# Import
from functions import linear_search

# Declare variables
num = int(input("Number of values: "))

# Empty list
a = []

# Initialize list
for i in range(num):
    # Prompt user with values inside list
    values = float(input("Enter a number: "))
    # Assign values to i index
    a.append(values)

# Print list
print(f"Values: {a}")

# Ask for value
v = float(input("Index of: "))

# Call function
index = linear_search(a, v)

# Output
print()
print(f"Index of {v}: {index}")
