"""
------------------------------------------------------------------------
[Finds the dot product of two matrices]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-11"
------------------------------------------------------------------------
"""
# Import
from functions import dot_product

# Declare variables
length = int(input("Length of matrices: "))

# Initialize empty lists
source1 = []
source2 = []

# Assign values to lists
for n in range(length):
    comp1 = float(input("Enter component for matrix 1: "))
    source1.append(comp1)
for m in range(length):
    comp2 = float(input("Enter component for matrix 2: "))
    source2.append(comp2)

# Print lists
print(f"Matrix 1: {source1}")
print(f"Matrix 2: {source2}")

# Call function
dp = dot_product(source1, source2)

# Output
print()
print(f"Dot product: {dp}")
