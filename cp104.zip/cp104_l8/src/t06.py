"""
------------------------------------------------------------------------
[Returns min, max, total, and average values of a list]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-11"
------------------------------------------------------------------------
"""
# Import
from functions import list_stats

# Declare variables
num = int(input("Number of values: "))

# Empty list
a = []

# Initialize list
for i in range(num):
    # Prompt user with values inside list
    values = float(input("Enter a number: "))
    # Assign values to i index
    a.append(values)

# Print list
print(f"Values: {a}")

# Call function
smallest, largest, total, average = list_stats(a)

# Output
print()
print(f"Smallest value: {smallest}")
print(f"Largest value: {largest}")
print(f"Total: {total}")
print(f"Average: {average}")
