"""
------------------------------------------------------------------------
[Returns n number of values between designated low and high values]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-10"
------------------------------------------------------------------------
"""
# Import
from functions import generate_integer_list

# Declare variables
num = int(input("Number of values: "))
low = int(input("Low value: "))
high = int(input("High value: "))

# Call function
values = generate_integer_list(num, low, high)

# Output
print()
print(f"Values: {values}")
