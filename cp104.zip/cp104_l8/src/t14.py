"""
------------------------------------------------------------------------
[Finds the intersection point(s) of two lists]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-11"
------------------------------------------------------------------------
"""  # Import
from functions import intersection

# Declare variables
length1 = int(input("Length of matrix 1: "))
length2 = int(input("Length of matrix 2: "))

# Initialize empty lists
source1 = []
source2 = []

# Assign values to lists
for n in range(length1):
    comp1 = float(input("Enter component for matrix 1: "))
    source1.append(comp1)
for m in range(length2):
    comp2 = float(input("Enter component for matrix 2: "))
    source2.append(comp2)

# Print lists
print(f"Matrix 1: {source1}")
print(f"Matrix 2: {source2}")

# Call function
target = intersection(source1, source2)

print()
print(f"Intersection: {target}")
