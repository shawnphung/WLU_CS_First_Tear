"""
------------------------------------------------------------------------
[Returns a month name corresponding to the user's input]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-10"
------------------------------------------------------------------------
"""
# Import
from functions import get_month_name

# Declare variable
month_num = int(input("Enter a month number (1-12): "))

# Call function
month_name = get_month_name(month_num)

# Output
print(f"The month is {month_name}")
