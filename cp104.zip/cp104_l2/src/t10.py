"""
------------------------------------------------------------------------
[Calculate a cost of a meal, including tax and tip, and prints a bill]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-23"
------------------------------------------------------------------------
"""
food = float(input("Food Charge: $"))
taxPercent = float(input("Sales Tax in (%): "))
tipPercent = float(input("Tip in (%): "))

"Calculations for tax, tip and total"
tax = food * (taxPercent / 100)
tip = food * (tipPercent / 100)
total = food + tax + tip

"Output"
print("")
print("Cost of meal:")
print("Subtotal: $ ", food)
print(f"Tax: $ {tax:.2f}")
print(f"Tip: $ {tip:.2f}")
print("----------------")
print(f"Total: $ {total:.2f}")
