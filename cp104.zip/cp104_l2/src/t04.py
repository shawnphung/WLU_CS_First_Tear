"""
------------------------------------------------------------------------
[Prompts user with 2 fractions and outputs the products]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-22"
------------------------------------------------------------------------
"""
n1 = int(input("First numerator: "))
d1 = int(input("First denominator: "))
n2 = int(input("Second numerator: "))
d2 = int(input("Second denominator: "))

"Calculate product"
r = (n1 / d1) * (n2 / d2)

print("Product: ", r)
