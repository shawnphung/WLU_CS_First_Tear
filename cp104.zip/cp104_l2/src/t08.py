"""
------------------------------------------------------------------------
[Calculates user's BMI/BMI' and compares it to South East Asia and Southern China]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-23"
------------------------------------------------------------------------
"""
"Prompt user with input"
height = float(input("Enter your height (m): "))
mass = int(input("Enter your weight (kg): "))
userUpper = float(input(
    "Enter your upper limit BMI (23 if you are from South East Asia and Southern China, 25 for everyone else): "))

"Calculate BMI and BMI Prime"
bmi = mass / (height ** 2)
bmiPrime = bmi / userUpper

"Output"
print("")
print("Body Mass Index (kg/m^2) = ", bmi)
print("BMI Prime = ", bmiPrime)
