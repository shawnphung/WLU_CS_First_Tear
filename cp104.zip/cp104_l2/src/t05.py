"""
------------------------------------------------------------------------
[Prompts user with hourly wage and number of hours worked, outputs total pay]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-22"
------------------------------------------------------------------------
"""
wage = float(input("Hourly rate of pay: "))
hours = float(input("Hours worked in a week: "))

"Calculate total pay"
total = float(wage * hours)

print("Total pay for the week: $ ", total)
