"""
------------------------------------------------------------------------
[Takes user input for temperature in F, and outputs temperature in Celcius]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-23"
------------------------------------------------------------------------
"""
FREEZING = 32
farh = int(input("Temperature (F): "))
"Calculate for Celcius"
celc = float((farh - FREEZING) * 5 / 9)

print("Temperature (C): ", celc)
