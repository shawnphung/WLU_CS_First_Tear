"""
------------------------------------------------------------------------
[Takes user input for number of big/small dogs groomed, outputs that info along with the total amount of money earned that day]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-20"
------------------------------------------------------------------------
"""
BIGPRICE = 75.00
SMALLPRICE = 50.00

big = int(input("Number of large dogs groomed: "))
small = int(input("Number of small dogs groomed: "))
total = int(BIGPRICE * big) + (SMALLPRICE * small)

print("Total earned for the day: ", total)
