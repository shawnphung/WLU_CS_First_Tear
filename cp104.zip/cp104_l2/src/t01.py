"""
------------------------------------------------------------------------
[Takes user input for temperature in Celcius, and outputs temperature in Fahrenheit]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-23"
------------------------------------------------------------------------
"""
FREEZING = 32
celc = int(input("Temperature (C): "))
fahr = float((9 / 5) * celc + FREEZING)

print("Temperature (F): ", fahr)
