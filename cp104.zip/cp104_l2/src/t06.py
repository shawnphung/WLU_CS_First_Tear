"""
------------------------------------------------------------------------
[Prompts user with values and calculates monthly mortgage]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-23"
------------------------------------------------------------------------
"""
"Prompt user with values"
principal = float(input("Mortgage principal ($): "))
totalYear = int(input("Number of years: "))
yearInterest = int(input("Yearly interest rate (%): "))

"Change yearly values to monthly values"
numberPayment = totalYear * 12
interestMonthly = (yearInterest / 12) / 100

numerator = interestMonthly * ((1 + interestMonthly) ** numberPayment)
denominator = ((1 + interestMonthly) ** numberPayment) - 1

"Calculate and output monthly mortgage rate"
monthly = principal * (numerator / denominator)
print(f"The monthly payments are: $ {monthly:.2f}")
