"""
------------------------------------------------------------------------
[Prompts user with number of seconds, and calculates total number of days, hours, minutes and secodns]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-23"
------------------------------------------------------------------------
"""
MINUTESEC = 60
secInput = int(input("Number of seconds: "))

"Calculate total time"
day = secInput // 84600
secInput = secInput % 86400

hour = secInput // 3600
secInput = secInput % 3600

minute = secInput // MINUTESEC
secInput = secInput % MINUTESEC

"Output"
print("")
print(f"Days: {day}, Hours: {hour}, Minutes: {minute}, Seconds: {secInput}")
