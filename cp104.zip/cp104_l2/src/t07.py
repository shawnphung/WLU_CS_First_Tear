"""
------------------------------------------------------------------------
[Prompts the user with number of flyers/volunteers, outputs average number of flyers per volunteer and how many are left over]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-23"
------------------------------------------------------------------------
"""
"Prompt user with values"
fTotal = int(input("Number of flyers: "))
vTotal = int(input("Number of volunteers: "))

"Calculate flyers"
fAvg = fTotal // vTotal
fLeft = fTotal % vTotal

"Output"
print("Flyers per volunteer: ", fAvg)
print("Flyers left over: ", fLeft)
