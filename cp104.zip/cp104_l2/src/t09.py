"""
------------------------------------------------------------------------
[Calculate the cost of producing an open-top cylindrical container and for x amount of them]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-23"
------------------------------------------------------------------------
"""
"Declare Constant"
PI = 3.14

"Prompt user with dimensions of container"
diameter = float(input("Diameter of container base (cm): "))
height = float(input("Height of container (cm): "))
matCost = float(input("Cost of material ($/cm^2): "))
num = int(input("Number of containers: "))

"Calculations for Surface Area"
lateralSA = 2 * PI * (diameter / 2) * height
baseSA = PI * ((diameter / 2)**2)
totalSA = lateralSA + baseSA

"Calculations for cost"
costOne = matCost * totalSA
costTotal = costOne * num

"Output"
print("")
print("The total cost of one container is $ ", costOne)
print("The total cost of all containers is $ ", costTotal)
