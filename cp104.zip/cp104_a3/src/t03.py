"""
------------------------------------------------------------------------
[converts an 8 digit number into a date (YYYY/MM/DD format)]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-12"
------------------------------------------------------------------------
"""
# Import
from functions import date_extract

# Declare variable
date_number = int(input("Enter a date in the format MMDDYYYY: "))

# Call function
year, month, day = date_extract(date_number)

# Output
print()
print(f"The reformatted date: {year}/{month:02d}/{day:02d}")
