"""
------------------------------------------------------------------------
[Converts square footage to acres]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-12"
------------------------------------------------------------------------
"""
# Import
from functions import feet_to_acres

# Declare variable
foot = float(input("Square footage: "))

# Call function
acre = feet_to_acres(foot)

# Output
print()
print(f"{acre:.2f} acres is equivalent to {foot:.2f} square feet")
