"""
------------------------------------------------------------------------
[Multiplies 2 fractions and outputs the product in fraction and decimal form]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-12"
------------------------------------------------------------------------
"""
# Import
from functions import multiply_fractions

# Declare variables
num1 = int(input("Numerator 1: "))
denom1 = int(input("Denominator 1: "))
num2 = int(input("Numerator 2: "))
denom2 = int(input("Denominator 2: "))

# Call function
numerator, denominator, product = multiply_fractions(
    num1, denom1, num2, denom2)

# Output
print()
print(f"Result: {numerator}/{denominator} = {product}")
