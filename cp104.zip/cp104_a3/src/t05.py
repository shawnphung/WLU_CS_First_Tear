"""
------------------------------------------------------------------------
[Provides a simple math question for the user to solve, outputs user input and expected value]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-12"
------------------------------------------------------------------------
"""
# Import
from functions import math_quiz

# Call function
math_quiz()
