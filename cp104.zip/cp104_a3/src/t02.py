"""
------------------------------------------------------------------------
[Takes dimensions of the lawn and mowing speed, calculates and outputs how much time it will take]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-12"
------------------------------------------------------------------------
"""
# Import
from functions import mow_lawn

# Declare variables
width = float(input("Width (m): "))
length = float(input("Length (m): "))
speed = float(input("Speed (m^2/minute): "))

# Call function
time = mow_lawn(width, length, speed)

# Output
print()
print(f"Mowing the lawn takes {time:.2f} minutes")
