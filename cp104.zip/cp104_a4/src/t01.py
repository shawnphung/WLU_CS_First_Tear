"""
------------------------------------------------------------------------
[Prints a day of the week based on the input (1-7 for Monday-Sunday respectively)]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-23"
------------------------------------------------------------------------
"""
# Import
from functions import day_of_week

# Declare variable
day_number = int(input("Enter a number from 1 to 7: "))

# Call function
day = day_of_week(day_number)

# Output
print(day)
