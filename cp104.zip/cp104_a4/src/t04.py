"""
------------------------------------------------------------------------
[Mixes the colours given by the input and outputs the combined colour]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-24"
------------------------------------------------------------------------
"""
# Import
from functions import rgb_mix

# Declare variable
rgb1 = input("Enter the first primary colour: ")
rgb2 = input("Enter the second primary colour: ")

# Call function
colour = rgb_mix(rgb1, rgb2)

# Output
print(f"Product: {colour}")
