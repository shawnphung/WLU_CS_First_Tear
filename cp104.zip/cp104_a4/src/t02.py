"""
------------------------------------------------------------------------
[Calculates the pollution level given an AQI input]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-23"
------------------------------------------------------------------------
"""
# Import
from functions import pollution_level

# Declare variable
aqi = int(input("Enter the AQI value: "))

# Call function
level = pollution_level(aqi)

# Output
print(level)
