"""
------------------------------------------------------------------------
[Outputs a sentence based on the quotient of the input and 7 and 3]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-24"
------------------------------------------------------------------------
"""
# Import
from functions import yee_ha

# Declare variable
number = int(input("Enter a number: "))

# Call function
sentence = yee_ha(number)

# Output
print(sentence)
