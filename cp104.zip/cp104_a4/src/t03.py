"""
------------------------------------------------------------------------
[Returns the product of the 2 largest values out of 3 inputs]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-23"
------------------------------------------------------------------------
"""
# Import
from functions import product_largest

# Declare variables
v1 = float(input("First number: "))
v2 = float(input("Second number: "))
v3 = float(input("Third number: "))

# Call function
product = product_largest(v1, v2, v3)

# Output
print(f"Product of the largest numbers: {product:.2f}")
