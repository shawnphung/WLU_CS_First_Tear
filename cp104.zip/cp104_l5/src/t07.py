"""
------------------------------------------------------------------------
[Calculates a worker's pay depending on their wage and overtime hours]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-20"
------------------------------------------------------------------------
"""
# Import
from functions import get_pay

# Declare variables
employee_ID = int(input("Employee ID: "))
hourly_rate = float(input("Hourly wage rate: "))
hours_worked = float(input("Hours worked: "))

# Call function
net_pay = get_pay(hourly_rate, hours_worked)

# Output
print(f"Net payment for employee {employee_ID}: ${net_pay:.2f}")
