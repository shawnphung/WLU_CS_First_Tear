"""
------------------------------------------------------------------------
[Calculates the damage level based on the intensity of a given earthquake]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-20"
------------------------------------------------------------------------
"""
# Import
from functions import richter

# Declare variable
n = float(input("Richter Scale Number: "))

# Call function
result = richter(n)

# Output
print()
print(result)
