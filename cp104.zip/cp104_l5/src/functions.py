"""
------------------------------------------------------------------------
[Holds all functions that are to be called upon]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-20"
------------------------------------------------------------------------
"""
# Gym cost function


def gym_cost(cost, friends):
    """
    -------------------------------------------------------
    Calculates total cost of a gym membership. A member gets a
    discount according to the number of friends they sign up.
        0 friends: 0% discount
        1 friend: 5% discount
        2 friends: 10% discount
        3 or more friends: 15% discount
    Use: final_cost = gym_cost(cost, friends)
    -------------------------------------------------------
    Parameters:
        cost - a gym membership base cost (float > 0)
        friends - number of friends signed up (int >= 0)
    Returns:
        final_cost - cost of membership after discount (float)
    ------------------------------------------------------
    """
    DISCOUNT1 = 0.05
    DISCOUNT2 = 0.10
    DISCOUNT3 = 0.15
    if friends == 0:
        final_cost = cost
    elif friends == 1:
        final_cost = cost - (cost * DISCOUNT1)
    elif friends == 2:
        final_cost = cost - (cost * DISCOUNT2)
    else:
        final_cost = cost - (cost * DISCOUNT3)
    return final_cost


# Leap year function
def is_leap(year):
    """
    -------------------------------------------------------
    Determines if a year is a leap year. Every year that is
    exactly divisible by four is a leap year, except for years
    that are exactly divisible by 100, but these centurial years
    are leap years if they are exactly divisible by 400. For
    example, the years 1700, 1800, and 1900 are not leap years,
    but the years 1600 and 2000 are.
    Use: result = is_leap(year)
    -------------------------------------------------------
    Parameters:
        year - a year (int > 0)
    Returns:
        result - True if year is a leap year,
            False otherwise (boolean)
    ------------------------------------------------------
    """
    if (year % 4 == 0) and (year % 100 != 0):
        result = True
    elif (year % 400 == 0):
        result = True
    else:
        result = False
    return result


# Get pay funtion
def get_pay(hourly_rate, hours_worked):
    """
    -------------------------------------------------------
    Calculates an employee's net wage given hours and pay.
    Each employee is paid 1.5 times their regular hourly rate for
    all hours over 40. A tax amount of 3.625 percent of gross salary
    is deducted.
    Use: net_payment = get_pay(hourly_rate, hours_worked)
    -------------------------------------------------------
    Parameters:
        hourly_rate - hourly rate of pay (float)
        hours_worked - total hours worked (float)
    Returns:
        net_payment - description (float)
    ------------------------------------------------------
    """
    NORM_HOURS = 40
    OVERTIME_RATE = 1.5
    TAX_RATE = 0.03625
    if hours_worked > NORM_HOURS:
        overtime = hours_worked - NORM_HOURS
        overtime_pay = overtime * OVERTIME_RATE * hourly_rate
        gross_pay = (NORM_HOURS * hourly_rate) + overtime_pay
        tax = gross_pay * TAX_RATE
    else:
        gross_pay = hours_worked * hourly_rate
        tax = gross_pay * TAX_RATE
    net_payment = gross_pay - tax
    return net_payment


# Richter function
def richter(intensity):
    """
    -------------------------------------------------------
    Determines damage level given earthquake intensity measured
    on the Richter scale.
    Use: result = richter(intensity)
    -------------------------------------------------------
    Parameters:
        intensity - Richter scale number for severity of earthquake
            (float >= 0)
    Returns:
        result - description of earthquake damage (str)
    -------------------------------------------------------
    """
    if intensity < 5:
        result = "Little or no damage"
    elif intensity < 5.5:
        result = "Some damage"
    elif intensity < 6.5:
        result = "Serious damage: walls may crack or fall"
    elif intensity < 7.5:
        result = "Disaster: buildings may collapse"
    else:
        result = "Catastrophe: most buildings destroyed"
    return result


# Fast food function
def fast_food():
    """
    -------------------------------------------------------
    Food order function.
    Asks user for their order and if they want a combo, and if
    necessary, what is the side order for the combo:
    Prices:
        Burger: $6.00
        Wings: $8.00
        Fries combo: add $1.50
        Salad combo: add $2.00
    Use: price = fast_food()
    -------------------------------------------------------
    Returns:
        price - the price of one meal (float)
    -------------------------------------------------------
    """
    BURGER = 6.00
    WINGS = 8.00
    FRIES = 1.50
    SALAD = 2.00

    burgOrWings = input("Order B - burger or W - Wings: ")
    if burgOrWings == "B":
        price = BURGER
    elif burgOrWings == "W":
        price = WINGS
    combo = input("Make it a combo? (Y/N): ")
    if combo == "Y":
        friesOrSalad = input("Add F - fries or S - salad: ")
        if friesOrSalad == "F":
            price = price + FRIES
        elif friesOrSalad == "S":
            price = price + SALAD
    elif combo == "N":
        price = price
    return price
