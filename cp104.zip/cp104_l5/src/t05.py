"""
------------------------------------------------------------------------
[Determines if the input year is a leap year]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-20"
------------------------------------------------------------------------
"""
# Import
from functions import is_leap

# Input
year = int(input("Year (>0): "))

# Call function
result = is_leap(year)

# Output
if result == True:
    print()
    print(f"{year} is a leap year")
elif result == False:
    print()
    print(f"{year} is not a leap year")
