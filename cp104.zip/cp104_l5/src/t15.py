"""
------------------------------------------------------------------------
[Calculates food bill based on user order]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-20"
------------------------------------------------------------------------
"""
# Import
from functions import fast_food

# Call function
price = fast_food()

# Output
print(f"Price: ${price:.2f}")
