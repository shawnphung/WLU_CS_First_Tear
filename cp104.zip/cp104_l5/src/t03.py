"""
------------------------------------------------------------------------
[Calculates gym membership cost based on base price and the number of friends that you signed up with]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-12"
------------------------------------------------------------------------
"""
# Import
from functions import gym_cost

# Declare variables
cost = float(input("Gym membership cost: $"))
friends = int(input("Number of friends signed up: "))

# Call function
final_cost = gym_cost(cost, friends)

print()
print(f"Your membership price is ${final_cost:.2f}")
