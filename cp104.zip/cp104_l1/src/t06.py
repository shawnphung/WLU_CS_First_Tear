"""
------------------------------------------------------------------------
[Adds salary and bonus, and outputs the sum, under a third variable]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-16"
------------------------------------------------------------------------
"""
# Calculate total pay
salary = 2500.0
bonus = 1200.0
pay = salary + bonus
print("Your pay is ", pay)
