"""
------------------------------------------------------------------------
[Asks for your name, greets you while printing your name]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-16"
------------------------------------------------------------------------
"""
name = input("Please enter your name: ")
print("Pleased to meet you ")
print(name)
