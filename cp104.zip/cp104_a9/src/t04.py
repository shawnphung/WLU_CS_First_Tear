"""
------------------------------------------------------------------------
[Returns a 1D list of a flattened matrix]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-05"
------------------------------------------------------------------------
"""
# Import
from functions import flatten

# Declare matrix
matrix = [1, 2, 3], [4, 5, 6], [7, 8, 9, 10]

# Call function
flat = flatten(matrix)

# Output
print(f"Original matrix: {matrix}")
print(f"Flattened matrix: {flat}")
