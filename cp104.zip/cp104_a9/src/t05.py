"""
------------------------------------------------------------------------
[Returns a rotated matrix]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-05"
------------------------------------------------------------------------
"""
# Import
from functions import matrix_rotate_right

# Declare matrix
matrix = [1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12]

# Call function
rotated = matrix_rotate_right(matrix)

# Output
print(f"Original matrix: {matrix}")
print(f"Rotated matrix: {rotated}")
