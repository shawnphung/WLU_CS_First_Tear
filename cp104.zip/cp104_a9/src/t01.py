"""
------------------------------------------------------------------------
[Reads and returns the first n lines in a given file]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-05"
------------------------------------------------------------------------
"""
# Import
from functions import file_head

# Declare variables
fh = open('functions.py', 'r', encoding='utf-8')

# Call function / output
file_head(fh, 3)
