"""
------------------------------------------------------------------------
[Returns statistics of a given file]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-05"
------------------------------------------------------------------------
"""
# Import
from functions import file_stats

# Declare variable
fh = open("functions.py", "r", encoding="utf-8")

# Call function
ucount, lcount, dcount, wcount = file_stats(fh)

# Output
print(f"Number of upper case letters: {ucount}")
print(f"Number of lower case letters: {lcount}")
print(f"Number of digits: {dcount}")
print(f"Number of whitespace characters: {wcount}")
