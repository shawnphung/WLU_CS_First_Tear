"""
------------------------------------------------------------------------
[Returns a person's name and address from a given file]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-05"
------------------------------------------------------------------------
"""
# Import
from functions import get_addresses

# Declare variable
fh = open('addresses.txt', 'r', encoding='utf-8')

# Call function
addresses = get_addresses(fh)

# Output
print(addresses)
