"""
------------------------------------------------------------------------
[Returns all positive integers from a given file]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-12-05"
------------------------------------------------------------------------
"""
# Import
from functions import file_integers

# Declare variable
fh = open('numbers.txt', 'r', encoding='utf-8')

# Call function
numbers = file_integers(fh)

# Output
print(numbers)
