"""
------------------------------------------------------------------------
[Contains functions to be called]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-14"
------------------------------------------------------------------------
"""
# Winner function


def winner():
    """
    -------------------------------------------------------
    Calculates and returns the factorial of num.
    Use: winner()
    -------------------------------------------------------
    Parameters:
        none
    Returns:
        grey - number of times grey team won
        blue - number of times blue team won
    ------------------------------------------------------
    """
    grey = 0
    blue = 0

    win = input("Enter the winning team: ")
    while win != "":
        if win == "grey":
            grey += 1
            win = input("Enter the winning team: ")
        elif win == "blue":
            blue += 1
            win = input("Enter the winning team: ")

    print(f"Blue: {blue}    Grey: {grey}")

    return blue, grey


# Prime number function
def is_prime(num):
    """
    -------------------------------------------------------
    Determines if num is a prime number.
    Use: prime = is_prime(num)
    -------------------------------------------------------
    Parameters:
        num - a positive integer (int > 1)
    Returns:
        prime - True if num is prime, False otherwise (bool)
    ------------------------------------------------------
    """
    i = 2
    prime = False
    if num == 1 or num == 2:
        prime = True
    else:
        while num % i != 0:
            i += 1
            if i < num:
                prime = False
            else:
                prime = True
    return prime


# Interest table function
def interest_table(principal, rate, payment):
    """
    -------------------------------------------------------
    Prints a table of monthly interest and payments on a loan.
    Use: interest_table(principal, rate, payment)
    -------------------------------------------------------
    Parameters:
        principal - original value of a loan (float > 0)
        rate - yearly interest rate as a % (float >= 0)
        payment - the monthly payment (float > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    balance = principal
    month = 1

    print(f"Principal: ${principal:.2f}")
    print(f"Interest rate: {rate:.2f}%")
    print(f"Monthly payment: ${payment:.2f}")

    print("------------------------------------")
    print("Month Interest    Payment    Balance")
    print("------------------------------------")

    while balance > 0:
        interest = rate / 100 * balance / 12
        balance = balance + interest
        if balance - payment > 0:
            balance = balance - payment
        else:
            payment = balance
            balance = 0
        print(f"{month:>5}{interest:>9.2f}{payment:>11.2f}{balance:11.2f}")
        month += 1
    return


# Digit count function
def digit_count(num):
    """
    -------------------------------------------------------
    Counts the number of digits in an integer.
    Use: count = digit_count(num)
    -------------------------------------------------------
    Parameters:
        num - an integer (int)
    Returns:
        count - the number of digits in num (int)
    ------------------------------------------------------
    """
    count = 0
    num = abs(num)
    while num > 0:
        count += 1
        num //= 10
    return count


# Factors sum function
def sum_factors(num):
    """
    -------------------------------------------------------
    Determines the sum of factors of an integer not including
    the integer itself. An integer's factors are the whole numbers
    that the integer can be evenly divided by.
    Use: total = sum_factors(num)
    -------------------------------------------------------
    Parameters:
        num - a positive integer (int >= 1)
    Returns:
        total - the total of num's factors (int)
    ------------------------------------------------------
    """
    sum = 1
    i = 2
    while i < num:
        if num % i == 0:
            sum += i
        i += 1
    return sum
