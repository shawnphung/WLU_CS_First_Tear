"""
------------------------------------------------------------------------
[Returns table of payments and interest]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-14"
------------------------------------------------------------------------
"""
# Import
from functions import interest_table

# Declare variables
principal = float(input("Principal: $"))
rate = float(input("Interest rate (%): "))
monthly = float(input("Month payment: $"))

# Call function / output
interest_table(principal, rate, monthly)
