"""
------------------------------------------------------------------------
[Returns the number of digits contained in an integer]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-14"
------------------------------------------------------------------------
"""
# Import
from functions import digit_count

# Declare variable
num = int(input("Enter a number: "))

# Call function
count = digit_count(num)

# Output
print(f"Count: {count}")
