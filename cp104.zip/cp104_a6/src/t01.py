"""
------------------------------------------------------------------------
[Returns the number of times teams blue/grey win]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-12"
------------------------------------------------------------------------
"""
# Import
from functions import winner

# Call function / output
winner()
