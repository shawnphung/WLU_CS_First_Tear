"""
------------------------------------------------------------------------
[Checks and returns whether a number is a prime number or not]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-12"
------------------------------------------------------------------------
"""
# Import
from functions import is_prime

# Declare variable
num = int(input("Enter a number: "))

# Call function
prime = is_prime(num)

# Output
print(prime)
