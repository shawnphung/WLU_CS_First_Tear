"""
------------------------------------------------------------------------
[Returns the sum of all factors of a number]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-14"
------------------------------------------------------------------------
"""
# Import
from functions import sum_factors

# Declare variable
num = int(input("Enter a number: "))

# Call function
sum = sum_factors(num)

# Output
print(f"Sum = {sum}")
