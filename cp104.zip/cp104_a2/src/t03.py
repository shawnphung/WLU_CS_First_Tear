"""
------------------------------------------------------------------------
[Converts an 8-digit integer into a date (YYYY/MM/DD and outputs the result]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
num = int(input("Enter a date in the format MMDDYYYY: "))

"Calculations for date"
month = int(num // 1000000)
day = int(num % 1000000 / 10000)
year = int(num % 10000)

"Output"
print(f"The reformatted date: {year}/{month:02d}/{day:02d}")
