"""
------------------------------------------------------------------------
[Calculates and outputs a projected tax report]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
RATE = 0.225
total = int(input("Enter the total sales: $"))

tax = total * RATE

"Output"
print("")
print(f"""Projected Tax Report
---------------------------------------
Total sales:     $ {total:.2f}
Annual tax:      % 22.50
---------------------------------------
Tax:             $ {tax:,.2f}
""")
