"""
------------------------------------------------------------------------
[Calculates and prints the difference between a 2-digit number input]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
num = int(input("Enter a positive digit number: "))

"Calculate for first and second digits"
first = num // 10
second = num % (first * 10)

"Calculate for the difference and output"
dif = first - second
print(f"The difference of the digits of {num} is {dif}")
