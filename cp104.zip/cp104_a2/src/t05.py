"""
------------------------------------------------------------------------
[Calculates the cost of concrete/bricks to build a shed]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-30"
------------------------------------------------------------------------
"""
length = float(input("Foundation length (m): "))
width = float(input("Foundation width (m): "))
heightF = float(input("Foundation height (m): "))
heightW = float(input("Wall height (m): "))
costC = float(input("Cost of concrete ($/m^3): "))
costB = float(input("Cost of bricks ($/m^2): "))

"Calculations"
concrete = float(length * width * heightF)
totalC = float(concrete * costC)
brick = float((2 * heightW * length) + (2 * heightW * width))
totalB = float(brick * costB)
total = float(totalC + totalB)

"Output"
print(f"""
Concrete needed for foundation (m^3): {concrete:,.2f}
Cost of concrete: ${totalC:,.2f}
Bricks needed for walls (m^2): ${brick:,.2f}
Cost of bricks: ${costB:,.2f}
Total cost: ${total:,.2f}""")
