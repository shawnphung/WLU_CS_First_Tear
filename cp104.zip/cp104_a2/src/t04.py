"""
------------------------------------------------------------------------
[Calculates and evenly divides x amount of balloons between x amount of kids, and the left over balloons]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-09-29"
------------------------------------------------------------------------
"""
balloon = int(input("Number of balloons: "))
kid = int(input("Number of children: "))

"Calculations"
each = balloon // kid
left = balloon % kid

"Output"
print(f"Each child receives {each} balloons")
print(f"Balloons that won't be distributed: {left}")
