"""
------------------------------------------------------------------------
[Returns a list with specified values removed]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-19"
------------------------------------------------------------------------
"""
# Import
from functions import subtract_lists

# Declare variables
minuend = []
subtrahend = []

# List of values
num_in1 = int(input("Number of values: "))
for a in range(num_in1):
    num = int(input("Enter a number: "))
    minuend.append(num)
print(f"List of values: {minuend}")

print()

# List of values to remove
num_in2 = int(input("Enter number of values to remove: "))
for b in range(num_in2):
    sub = int(input("Enter a number to remove: "))
    subtrahend.append(sub)
print(f"List of values to remove: {subtrahend}")

# Call function
minuend = subtract_lists(minuend, subtrahend)

# Output
print()
print(minuend)
