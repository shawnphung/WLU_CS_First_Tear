"""
------------------------------------------------------------------------
[Returns a list of positive numbers from a list provided]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-19"
------------------------------------------------------------------------
"""
# Import
from functions import list_positives

# Call function / output
list_positives()
