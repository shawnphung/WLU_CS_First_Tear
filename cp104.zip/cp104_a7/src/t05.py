"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-22"
------------------------------------------------------------------------
"""
# Import
from functions import is_sorted

# Declare List
values = [3, 2, 1]

# Call function
is_sorted, index = is_sorted(values)

# Output
print(f"Values: {values}")
print(f"{is_sorted}, {index}")
