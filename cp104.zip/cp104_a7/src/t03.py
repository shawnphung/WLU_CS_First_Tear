"""
------------------------------------------------------------------------
[Returns the index of the target value inside a list]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-19"
------------------------------------------------------------------------
"""
# Import
from functions import list_indexes

# Declare variables
num = int(input("Number of values: "))
values = []

# Takes values
for i in range(num):
    num_list = int(input("Enter a number: "))
    values.append(num_list)

target = int(input("Enter target number: "))

# Call function
locations = list_indexes(values, target)

# Output
print()
print(f"Values: {values}")
print(f"Index(es) of target: {locations}")
