"""
------------------------------------------------------------------------
[Returns a list of factors for user defined number]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-19"
------------------------------------------------------------------------
"""
# Import
from functions import list_factors

# Declare variable
num = int(input("Enter a number: "))

# Call function
factors = list_factors(num)

# Output
print(f"Factors: {factors}")
