"""
------------------------------------------------------------------------
[Prints an open triangle with the character # given the number of rows]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-07"
------------------------------------------------------------------------
"""
# Import
from functions import open_triangle

# Declare variable
num_rows = int(input("Enter number of rows: "))

# Call function / output
open_triangle(num_rows)
