"""
------------------------------------------------------------------------
[Prints a multiplication table based on start and stop values]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-07"
------------------------------------------------------------------------
"""
# Import
from functions import multiplication_table

# Declare variables
start = int(input("Enter start value: "))
stop = int(input("Enter stop value: "))

# Call function / output
multiplication_table(start, stop)
