"""
------------------------------------------------------------------------
[User inputs the start/stop values and increment of a range, output the total of said range ]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-07"
------------------------------------------------------------------------
"""
# Import
from functions import range_total

# Declare variables
start = int(input("Enter starting value: "))
increment = int(input("Enter the increment value: "))
count = int(input("Enter the number of values in the range: "))

# Call function
total = range_total(start, increment, count)

# Output
print()
print(
    f"The sum of {count} values starting from {start} with an increment of {increment} is {total}")
