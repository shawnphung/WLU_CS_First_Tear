"""
------------------------------------------------------------------------
[Calculates and output the factorial of a given number]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-07"
------------------------------------------------------------------------
"""
# Import
from functions import factorial

# Declare variable
num = int(input("Enter a number: "))

# Call function
product = factorial(num)

# Output
print(f"{num}! = {product}")
