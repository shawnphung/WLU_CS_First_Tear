"""
------------------------------------------------------------------------
[Holds all functions to be called on]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-07"
------------------------------------------------------------------------
"""
# Factorial function


def factorial(num):
    """
    -------------------------------------------------------
    Calculates and returns the factorial of num.
    Use: product = factorial(num)
    -------------------------------------------------------
    Parameters:
        num - number to factorial (int > 0)
    Returns:
        product - num! (int)
    ------------------------------------------------------
    """
    product = 1
    for i in range(num, 0, -1):
        product *= i
    return product


# Calories function
def calories_burned(per_minute, minutes):
    """
   -------------------------------------------------------
   Calculates and returns the amount of calories burned every 5 minutes.
   Use: calories_burned(per_minute, minutes)
   -------------------------------------------------------
   Parameters:
       per_minute - calories burned by the user every minute (float > 0)
       minutes - the amount of time the user spends burning calories (int > 0)
   Returns:
       none
   ------------------------------------------------------
   """
    for i in range(5, minutes + 1, 5):
        cals_burned = per_minute * i
        print(f"{i:>3}:{cals_burned:>10.1f}")
    return


# Open triangle function
def open_triangle(num_rows):
    """
   -------------------------------------------------------
   Prints an open triangle of '#' characters with an empty center; size depends on user input
   Use: open_triangle(num_rows)
   -------------------------------------------------------
   Parameters:
      num_rows - number of rows to be printed (int > 0)
   Returns:
       none
   ------------------------------------------------------
   """
    for i in range(0, num_rows):
        print("#" + (" " * i) + "#")
    return


# Multiplication table function
def multiplication_table(start, stop):
    """
    -------------------------------------------------------
    Prints a multiplication table for values from start to stop.
    Use: multiplication_table(start, stop)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        stop - the range stop value (int)
    Returns:
        None
    ------------------------------------------------------
    """
    # Top row
    print("       ", end="")
    for i in range(start, stop + 1):
        print(f"{i:5d}", end="")
    # Dashes
    print()
    dashes = "-----" * (stop - start + 1)
    print(f"       {dashes}")

    # Left axis (numbers)
    for num1 in range(start, stop + 1):
        print()
        print(f"{num1:5d} |", end="")
    # Products
        for num2 in range(start, stop + 1):
            product = num1 * num2
            print(f"{product:5d}", end="")
    return


# Range total function
def range_total(start, increment, count):
    """
    -------------------------------------------------------
    Uses a for loop to sum count values from start by increment.
    Use: total = range_total(start, increment, count)
    -------------------------------------------------------
    Parameters:
        start - the range start value (int)
        increment - the range increment (int)
        count - the number of values in the range (int)
    Returns:
        total - the sum of the range (int)
    ------------------------------------------------------
    """
    total = 0
    for i in range(start, increment * count + start, increment):
        total += i
    return total
