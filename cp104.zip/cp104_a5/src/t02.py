"""
------------------------------------------------------------------------
[Prints a table displaying how many calories the user burns in 5 minute intervals]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-07"
------------------------------------------------------------------------
"""
# Import
from functions import calories_burned

# Declare variables
per_minute = float(input("Calories burned per minute: "))
minutes = int(input("Enter number of minutes spent: "))

# Call function / output
calories_burned(per_minute, minutes)
