"""
------------------------------------------------------------------------
[Performs mathematical calculation on 2 single digit numbers]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-18"
------------------------------------------------------------------------
"""
# Import
from functions import calculate

# Declare variable
expr = input("Enter an expression: ")

# Call function
result = calculate(expr)

# Output
print(f"{expr} = {result}")
