"""
------------------------------------------------------------------------
[Checks and returns if the input code is valid based on set criteria]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-18"
------------------------------------------------------------------------
"""
product = 'ABC1234Abcd'
print()
# Validate category
category = product[:3]
if category.isalpha() and category.isupper():
    print(category)
    print(f"Category {category} is valid.")
else:
    print(f"Category {category} is not valid.")

 # Validate ID
id = product[3:7]
print(id)
if id.isdigit():
    print(f"ID {id} is valid.")
else:
    print(f"ID {id} is not valid.")

    # Validate
qualifier = product[7:len(product)]
print(qualifier)
if qualifier[0].isupper():
    print(f"Qualifier {qualifier} is valid.")
else:
    print(f"Qualifier {qualifier} is not valid.")
