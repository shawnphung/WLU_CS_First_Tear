"""
------------------------------------------------------------------------
[Returns if the input string is a palindrome or not]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-18"
------------------------------------------------------------------------
"""
# Import
from functions import is_palindrome

# Declare variables
s = input("Enter a string: ")

# Call function
palindrome = is_palindrome(s)

# Output
if palindrome == True:
    print(f"'{s}' is a palindrome")
else:
    print(f"'{s}' is not a palindrome")
