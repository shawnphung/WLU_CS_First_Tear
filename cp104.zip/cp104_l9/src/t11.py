"""
------------------------------------------------------------------------
[Removes all vowels from input string and returns new string]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-18"
------------------------------------------------------------------------
"""
# Import
from functions import dsmvwl

# Declare variable
s = input("Enter a string: ")

# Call function
out = dsmvwl(s)

# Output
print(f"Disemvowelled: {out}")
