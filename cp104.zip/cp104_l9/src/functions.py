"""
------------------------------------------------------------------------
[Holds functions to be called]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-18"
------------------------------------------------------------------------
"""
# URL categorization function


def url_categorize(url):
    """
    -------------------------------------------------------
    Returns whether a url represents a business, a non-profit, or another
    type of organization.
    Use: url_type = url_categorize(url)
    -------------------------------------------------------
    Parameters:
        url - the web address of the organization (str)
    Returns:
        url_type - the organization type (str)
            'business' if url ends with 'com'
            'non-profit' if url ends with 'org'
            'other' if url ends with something else
    ------------------------------------------------------
    """
    domain = url[-3:]
    if domain == "com":
        url_type = 'business'
    elif domain == "org":
        url_type = 'non-profit'
    else:
        url_type = 'other'
    return url_type


# Code validator function
def validate_code(product_code):
    """
    -------------------------------------------------------
    Parses a given product code and prints whether the various parts are valid.
    A product code has three parts:
        The first three letters describe the product category and must
        all be in upper case.
        The next four digits are the product ID.
        The remaining characters describe the product's qualifiers,
        such as colour, size, etc. and always begins with an uppercase letter.
    Use: validate_code(product_code)
    -------------------------------------------------------
    Parameters:
        product_code - a product code (str)
    Returns:
        None
    -------------------------------------------------------
    """
    print()

    category = product_code[:3]
    _id = product_code[3:7]
    qualifier = product_code[7:]

    # Validate category
    if len(category) == 3 and category.isupper():
        print(f"Category {category:s} is valid.")
    else:
        print(f"Category {category:s} is not valid.")

    # Validate ID
    if len(_id) == 4 and _id.isnumeric():
        print(f"ID {_id} is valid.")
    else:
        print(f"ID {_id} is not valid.")

    # Validate qualifier
    if qualifier and qualifier[0].isupper():
        print(f"Qualifier {qualifier} is valid.")
    else:
        print(f"Qualifier {qualifier} is not valid.")

    return


# Palindrome function
def is_palindrome(s):
    """
    -----------------------------------------------------------------
    Checks whether the given string is palindrome or not. A palindrome is
    a string the reads the same forwards as backwards. Case is ignored.
    Use: palindrome = is_palindrome(s)
    -----------------------------------------------------------------
    Parameters:
        s - a string to be checked (str)
    Returns:
        palindrome - True if s is a palindrome, False otherwise (boolean)
    -----------------------------------------------------------------
    """
    # Declare variable
    original = []
    reverse = []
    palindrome = False

    # Create original list
    for n in range(0, len(s)):
        char1 = s[n].lower()
        original.append(char1)

    # Create reverse list
    for i in range(len(s) - 1, -1, -1):
        char2 = s[i].lower()
        reverse.append(char2)

    # Palindrome validator
    if reverse == original:
        palindrome = True
    else:
        palindrome = False
    return palindrome


# Digit count function
def digit_count(s):
    """
    -------------------------------------------------------
    Counts the number of digits in a string.
    Use: count = digit_count(s)
    -------------------------------------------------------
    Parameters:
        s - a string (str)
    Returns:
        count - the number of digits in s (int)
    -------------------------------------------------------
    """
    count = 0

    for i in range(len(s)):
        if s[i].isdigit():
            count += 1
    return count


# Consonants-only function
def dsmvwl(s):
    """
    -------------------------------------------------------
    Disemvowels a string. Returns a copy of s with all the vowels
    removed. Y is not treated as a vowel. Preserves case.
    Use: out = dsmvwl(s)
    -------------------------------------------------------
    Parameters:
        s - a string (str)
    Returns:
        out - s with its vowels removed (str)
    -------------------------------------------------------
    """
    out = ""
    vowels = ['a', 'e', 'i', 'o', 'u']

    for i in range(len(s)):
        if s[i].lower() not in vowels:
            out += s[i]
    return out


# Arithmetic operation function
def calculate(expr):
    """
    -----------------------------------------------------------------
    Treats expr as a math expression and evaluates it.
    expr must have the following format:
        operand1 operator operand2
    operators are: +, -, *, /, %
    operands are one-digit integer numbers
    Return None if second operand is zero for division.
    Use: result = calculate(expr)
    -----------------------------------------------------------------
    Parameters:
        expr - an arithmetic expression to be calculated (str)
    Returns:
        result - The result of arithmetic expression (float)
    -----------------------------------------------------------------
    """
    operand1 = float(expr[0])
    operand2 = float(expr[4])
    operator = expr[2]
    result = None

    if operator == '+':
        result = int(operand1 + operand2)
    elif operator == '-':
        result = int(operand1 - operand2)
    elif operator == '*':
        result = int(operand1 * operand2)
    elif operator == '/' and operand2 != 0:
        result = int(operand1 / operand2)
    elif operator == '%' and operand2 != 0:
        result = int(operand1 % operand2)
    return result
