"""
------------------------------------------------------------------------
[Returns the number of digits present in input string]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-18"
------------------------------------------------------------------------
"""
# Import
from functions import digit_count

# Declare variable
s = input("Enter a string: ")

# Call function
count = digit_count(s)

# Output
print(f"There are {count} digits.")
