"""
------------------------------------------------------------------------
[Returns the type of website category the input url is under]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-18"
------------------------------------------------------------------------
"""
# Import
from functions import url_categorize

# Declare variable
url = input("Enter a url: ")

# Call function
url_type = url_categorize(url)

# Output
print(f"The url represents a {url_type} website")
