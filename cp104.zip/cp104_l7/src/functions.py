"""
------------------------------------------------------------------------
[Contains functions to be called]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-04"
------------------------------------------------------------------------
"""
# Closest power function


def power_of_two(target):
    """
    -------------------------------------------------------
    Determines the nearest power of 2 greater than or equal to
    a given target.
    Use: power = power_of_two(target)
    -------------------------------------------------------
    Parameters:
        target - value to find nearest power of 2 (int >= 0)
    Returns:
        power - first power of 2 >= target (int)
    -------------------------------------------------------
    """
    power = 1  # value init to 2^0

    while(power < target):
        power = power * 2
    return power

# Sum of squares function


def sum_squares(target):
    """
    -------------------------------------------------------
    Determines the sum of squares closest to, and greater than or
    equal to, a target value.
    Use: final = sum_squares(target)
    -------------------------------------------------------
    Parameters:
        target - target value (int >= 0)
    Returns:
        final - the final sum of squares >= target (int)
    -------------------------------------------------------
    """
    final = 0
    i = 1

    while (final - 1) < target:
        final = final + (i ** 2)
        i += 1
    return final


# Num categories function
def num_categories():
    """
    -------------------------------------------------------
    Asks a user to enter a series of numbers, then counts and returns
    how may positives, negatives, and zeroes there are.
    Stop processing values when the user enters -999.
    Use: negatives, zeroes, positives = num_categories()
    -------------------------------------------------------
    Returns:
        negatives - number of negative values (int)
        zeroes - number of zero values (int)
        positives - number of positive values (int)
    ------------------------------------------------------
    """
    positives = 0
    negatives = 0
    zeroes = 0
    userInput = float(input("First value: "))

    while (userInput != -999):  # As long as input != -999
        if (userInput > 0):
            positives += 1
        elif (userInput < 0):
            negatives += 1
        else:
            zeroes += 1
    # Takes user input again
        userInput = float(input("Next value: "))
    # Output
    print()
    print("Negatives: ", negatives)
    print("Zeroes: ", zeroes)
    print("Positives: ", positives)

    return negatives, zeroes, positives


# Budget function
def budget(available):
    """
    -------------------------------------------------------
    Asks a user for a series of expenses in a month. Calculate the
    total expenses and determines whether the user is in "Surplus",
    "Deficit", or "Balanced" status.
    Use: expenses, balance, status = budget(available)
    -------------------------------------------------------
    Parameters:
        available - money currently available (float >= 0)
    Returns:
        expenses - total monthly expenses (float)
        balance - remaining balance (float)
        status - One of (str):
            "Surplus" if user budget is in surplus
            "Deficit" if user budget is in deficit
            "Balanced" if user budget is balanced
    -----------------------------------------------status - One of (str):
            "Surplus" if user budget is in surplus
            "Deficit" if user budget is in deficit
            -------
    """
    balance = available
    expenses = float(input("Enter an expense (0 to quit): $"))
    totalExpenses = 0

    while expenses != 0:
        balance = balance - expenses
        totalExpenses += expenses
        expenses = float(input("Enter another expense (0 to quit): $"))

    if balance < 0:
        status = "Deficit"
    elif balance > 0:
        status = "Surplus"
    else:
        status = "Balanced"

    return totalExpenses, balance, status


# Low/High function
def get_int(low, high):
    """
    -------------------------------------------------------
    Asks a user for an integer value between low and high, and
    continues asking until an acceptable value is input.
    Use: value = get_int(low, high)
    -------------------------------------------------------
    Parameters:
        low - the lowest acceptable integer (inclusive) (int)
        high - the higest acceptable integer (inclusive) (int > low)
    Returns:
        value - a number between low and high (int)
    ------------------------------------------------------
    """
    print()
    value = int(input(f"Enter a value between {low} and {high}: "))

    while value < low or value > high:
        if value < low:
            print("Value is too low")
            value = int(input(f"Enter a value between {low} and {high}: "))
        elif value > high:
            print("Value is too high")
            value = int(input(f"Enter a value between {low} and {high}:  "))

    return value
