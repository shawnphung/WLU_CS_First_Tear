"""
------------------------------------------------------------------------
[Takes user input and prints the closest sum of squares to said number]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-02"
------------------------------------------------------------------------
"""
# Import
from functions import sum_squares

# Declare variable
target = int(input("Enter a number: "))

# Call function
final = sum_squares(target)

# Output
print(final)
