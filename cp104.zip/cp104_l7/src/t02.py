"""
------------------------------------------------------------------------
[Takes user input and returns the closest power of two equal to or greater than that number]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-02"
------------------------------------------------------------------------
"""
# Import
from functions import power_of_two

# Declare variable
target = int(input("Enter a number: "))

# Call function
power = power_of_two(target)

# Output
print(power)
