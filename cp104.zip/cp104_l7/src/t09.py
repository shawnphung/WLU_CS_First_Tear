"""
------------------------------------------------------------------------
[Takes user input for a number floor and ceiling and returns user input that is between said numbers]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-04"
------------------------------------------------------------------------
"""
# Import
from functions import get_int

# Declare variables
low = int(input("Enter the lowest acceptable number: "))
high = int(input("Enter the highest acceptable number: "))

# Call function
value = get_int(low, high)

# Output
print()
print(f"Value: {value}")
