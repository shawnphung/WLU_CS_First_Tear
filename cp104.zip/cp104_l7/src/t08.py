"""
------------------------------------------------------------------------
[Determines whether the user's budget is at a deficit/profit/balanced based on their starting value and expenses]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-04"
------------------------------------------------------------------------
"""
# Import
from functions import budget

# Declare variables
available = float(input("Monthly budget: $"))

# Call variables
expenses, balance, status = budget(available)

# Output
print()
print(f"Total expenses: ${expenses:.2f}")
print(f"{status}: ${balance:.2f}")
