"""
------------------------------------------------------------------------
[Asks user for a series of numbers, and outputs the amount of negative/positive numbers and zeroes, as long as the input isn't -999]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-02"
------------------------------------------------------------------------
"""
# Import
from functions import num_categories

# Call function / output
num_categories()
