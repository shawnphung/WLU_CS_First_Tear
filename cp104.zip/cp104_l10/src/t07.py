"""
------------------------------------------------------------------------
[Returns and appends the highest number to the end of fh]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-24"
------------------------------------------------------------------------
"""
# Import
from functions import append_max_num

# Declare variable
fh = open("numbers.txt", "r+", encoding="utf-8")

# Call function
num = append_max_num(fh)

# Output
print("file 'numbers.txt' open for reading and writing")
print(f"{num} is appended")
