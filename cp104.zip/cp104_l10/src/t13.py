"""
------------------------------------------------------------------------
[Copy contents from fh_1 to fh_2 while overwriting everything ]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-24"
------------------------------------------------------------------------
"""
# Import
from functions import file_copy

# Declare variables
fh_1 = open('words.txt', 'r', encoding='utf-8')
fh_2 = open('new_words.txt', 'w', encoding='utf-8')

# Call function / output
file_copy(fh_1, fh_2)
print("Copying 'words.txt' to 'new_words.txt'")
