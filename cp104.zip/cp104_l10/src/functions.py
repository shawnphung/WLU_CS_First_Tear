"""
------------------------------------------------------------------------
[Holds functions to be called]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-24"
------------------------------------------------------------------------
"""
# Customer record function


def customer_record(fh, n):
    """
    -------------------------------------------------------
    Find the n-th record in a comma-delimited sequential file.
    Records are numbered starting with 0.
    Use: result = customer_record(fh, n)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
        n - the number of the record to return (int > 0)
    Returns:
        result - a list of the fields of the n-th record if it exists,
            an empty list otherwise (list)
    -------------------------------------------------------
    """
    result = []
    counter = -1
    fh.seek(0)

    while counter != n:
        line = fh.readline()
        counter += 1
        line = line.strip()
        result = line.split(",")

    if result[0] == "":
        result.pop(0)

    return result


# Best customer function
def customer_best(fh):
    """
    -------------------------------------------------------
    Find the customer with the largest balance.
    Assumes file is not empty.
    Use: result = customer_best(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading)
    Returns:
        result - the record with the greatest balance (list)
    -------------------------------------------------------
    """
    result = []
    highest = 0
    fh.seek(0)
    num = 0
    line = fh.readline()

    x = line.strip()
    list = x.split(",")

    while line != "":
        num = float(list[3])
        if num > highest:
            highest = num
            result = list
        line = fh.readline()
        x = line.strip()
        list = x.split(",")

    return result


# Append max number function
def append_max_num(fh):
    """
    -------------------------------------------------------
    Appends a number to the end of fh. The number appended
    is the maximum of all the numbers currently in the file.
    Assumes file is not empty.
    Use: num = append_max_num(fh)
    -------------------------------------------------------
    Parameters:
        fh - file to search (file handle - already open for reading/writing)
    Returns:
        num - the number appended to the file (int)
    ------------------------------------------------------
    """
    highest = 0
    line = fh.readline()
    num = int(line.strip())

    while line != "":
        num = int(line.strip())
        if num > highest:
            highest = num
        line = fh.readline()

    fh.write(f"\n{highest}")
    return highest


# Copy file function
def file_copy(fh_1, fh_2):
    """
    -------------------------------------------------------
    Copies the contents of fh_1 to fh_2.
    Any contents of fh_2 are overwritten.
    Use: file_copy(fh_1, fh_2)
    -------------------------------------------------------
    Parameters:
        fh_1 - source file (file handle - already open for reading)
        fh_2 - target file (file handle - already open for writing)
    Returns:
        None
    ------------------------------------------------------
    """
    line = fh_1.readline()

    while line != '':
        fh_2.write(f'{line}')
        line = fh_1.readline()

    return


# Copy file n function


def file_copy_n(fh_1, fh_2, n):
    """
    -------------------------------------------------------
    Copies n record from fh_1 (starting from the beginning of the file) to fh2
    Use: file_copy_n(fh_1, fh_2, n)
    -------------------------------------------------------
    Parameters:
        fh_1 - file to search (file handle - already open for reading)
        fh_2 - file to search (file handle - already open for appending)
        n - number of lines to copy from fh_1 to fh_2
    Returns:
        None
    ------------------------------------------------------
    """
    line = fh_1.readline()
    count = 1

    while count <= n:
        new_line = line
        fh_2.write(f'{line}')
        line = fh_1.readline()
        count += 1
    return
