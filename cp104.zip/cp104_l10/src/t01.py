"""
------------------------------------------------------------------------
[Returns the customer information based on the entry number]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-24"
------------------------------------------------------------------------
"""
# Import
from functions import customer_record

# Declare variables
n = int(input("Enter record number: "))
fh = open("customers.txt", "r", encoding="utf-8")

# Call function
result = customer_record(fh, n)

# Output
print("Find record n")
print(result)
