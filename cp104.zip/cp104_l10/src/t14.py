"""
------------------------------------------------------------------------
[Copies n record from fh_1 (starting from the beginning of the file) to fh2]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-24"
------------------------------------------------------------------------
"""
# Import
from functions import file_copy_n

# Declare variables
fh_1 = open('words.txt', 'r', encoding='utf-8')
fh_2 = open('new_words.txt', 'a', encoding='utf-8')

print("Copying 'words.txt' to 'new_words.txt'")
n = int(input("Number of lines to copy: "))

# Call function
file_copy_n(fh_1, fh_2, n)
