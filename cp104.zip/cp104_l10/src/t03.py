"""
------------------------------------------------------------------------
[Returns the customer with the highest balance]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-24"
------------------------------------------------------------------------
"""
# Import
from functions import customer_best

# Declare variable
fh = open("customers.txt", "r", encoding="utf-8")

# Call function
result = customer_best(fh)

# Output
print("Find customer with largest balance: ")
print(result)
