"""
------------------------------------------------------------------------
[Finds the longest common ending between two string]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-28"
------------------------------------------------------------------------
"""
# Import
from functions import common_ending

# Declare variables
string1 = input("Enter the first string: ")
string2 = input("Enter the second string: ")

# Call function
common = common_ending(string1, string2)

# Output
print()
print(f"Common ending: {common}")
