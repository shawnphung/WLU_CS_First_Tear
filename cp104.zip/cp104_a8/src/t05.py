"""
------------------------------------------------------------------------
[Determines if a list of strings is a word chain]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-28"
------------------------------------------------------------------------
"""
# Import
from functions import is_word_chain

# Declare variable
word_list = []
num = int(input("Number of words: "))

# Append string
for i in range(num):
    string = input("Enter a word: ")
    word_list.append(string)

# Call function
word_chain = is_word_chain(word_list)

# Output
print()
print(f"Word List: {word_list}")
print(word_chain)
