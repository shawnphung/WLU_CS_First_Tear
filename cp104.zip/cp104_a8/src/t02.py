"""
------------------------------------------------------------------------
[Turns a singular word into a plural word]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-28"
------------------------------------------------------------------------
"""
# Import
from functions import pluralize

# Declare variable
string = input("Enter a word in singular form: ")

# Call function
plural = pluralize(string)

# Output
print(plural)
