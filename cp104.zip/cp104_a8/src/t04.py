"""
------------------------------------------------------------------------
[Checks to see if the string is a valid ISBN code]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-28"
------------------------------------------------------------------------
"""
# Import
from functions import is_valid_isbn

# Declare variable
isbn = '974-3-16-148410-'

# Call function
valid = is_valid_isbn(isbn)

# Output
print(f'ISBN": {isbn}')
print(valid)
