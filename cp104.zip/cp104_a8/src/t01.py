"""
------------------------------------------------------------------------
[Create and return a string with added spaces in between each word, while making the new word lower-cased]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-11-28"
------------------------------------------------------------------------
"""
# Import
from functions import add_spaces

# Declare variable
string = input("Enter a string: ")

# Call function
new_string = add_spaces(string)

# Output
print(new_string)
