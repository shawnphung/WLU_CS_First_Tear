"""
------------------------------------------------------------------------
[Draws a pyramid/triangle with a character given by the user based on specified height]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-29"
------------------------------------------------------------------------
"""
# Import
from functions import draw_triangle

# Declare variables
height = int(input("Enter height in characters: "))
char = input("Enter the draw character: ")

# Call function / output
draw_triangle(height, char)
