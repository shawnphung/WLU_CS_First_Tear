"""
------------------------------------------------------------------------
[Holds code to functions that are to be called]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-29"
------------------------------------------------------------------------
"""
# Sum even function


def sum_even(num):
    """
    -------------------------------------------------------
    Sums and returns the total of all even numbers from 2 to num (inclusive).
    Use: total = sum_even(num)
    -------------------------------------------------------
    Parameters:
        num - an integer (int > 0)
    Returns:
        total - sum of all even numbers from 2 to num (int)
    ------------------------------------------------------
    """
    even = 2
    total = 0
    for even in range(2, num + 1, 2):
        total += even
    return total


# Draw triangle function

def draw_triangle(height, char):
    """
    -------------------------------------------------------
    Prints a triangle of height characters using
    the char character.
    Use: draw_triangle(height, char)
    -------------------------------------------------------
    Parameters:
        height - number of characters high (int > 0)
        char - the character to draw with (str, len() == 1)
    Returns:
        None
    ------------------------------------------------------
    """
    rows = height * 2
    for i in range(1, rows, 2):
        print((height - 1) * ' ' + i * char)
        height -= 1
    return


# Beer bottles function
def bottles_of_beer(n):
    """
    -------------------------------------------------------
    Prints n verses of the song "99 Bottles of Beer on the Wall".
    Use: bottles_of_beer(n)
    -------------------------------------------------------
    Parameters:
        n - number of verses of the song to print (int > 0)
    Returns:
        None
    ------------------------------------------------------
    """
    if n > 2:
        for i in range(n, 2, -1):
            print(f"{i} bottles of beer on the wall, {i} bottles of beer.")
            print(
                f"Take one down, pass it around, {i-1} bottles of beer on the wall.")
            print("--")
            n -= 1
            print("2 bottles of beer on the wall, 2 bottles of beer.")
            print("Take one down, pass it around, 1 bottle of beer on the wall.")
            print("--")
            print("1 bottle of beer on the wall, 1 bottle of beer.")
            print("Take one down, pass it around, no more bottles of beer on the wall!")
    elif n == 2:
        print("2 bottles of beer on the wall, 2 bottles of beer.")
        print("Take one down, pass it around, 1 bottle of beer on the wall.")
        print("--")
        print("1 bottle of beer on the wall, 1 bottle of beer.")
        print("Take one down, pass it around, no more bottles of beer on the wall!")
    else:
        print("1 bottle of beer on the wall, 1 bottle of beer.")
        print("Take one down, pass it around, no more bottles of beer on the wall!")
    return


# Retirement function
def gic(value, years, rate):
    """
    -------------------------------------------------------
    Calculates and prints a table of how much a GIC (Guaranteed
    Income Certificate) is worth over a number of years, and
    returns its final value.
    Use: final_value = gic(value, years, rate)
    -------------------------------------------------------
    Parameters:
        value - GICs initial value (int > 0)
        years - number of years to maturity (int > 0)
        rate - percent increase value per year (float > 0)
    Returns:
        final_value - the final value of the GIC (float)
    ------------------------------------------------------
    """
    final_value = value
    print()
    print(f"Year {'Value $':>15}")
    print("-------------------")
    print(f"  0{value:>17,.2f}")
    for i in range(1, years + 1, 1):
        final_value = final_value + (final_value * (rate / 100))
        print(f"{i:>3}{final_value:>17,.2f}")
    return final_value


# Statistics function
def statistics(n):
    """
    -------------------------------------------------------
    Asks a user to enter n values, then calculates and returns
    the minimum, max, total, and average of those values.
    Use: minimum, maximum, total, average = statistics(n)
    -------------------------------------------------------
    Parameters:
        n - number of values to process (int > 0)
    Returns:
        minimum - smallest of n values (float)
        maximum - largest of n values (float)
        total - total of n values (float)
        average - average of n values (float)
    ------------------------------------------------------
    """
    m = float(input("First value: "))
    minimum = m
    maximum = m
    total = m
    for i in range(1, n, 1):
        m = float(input("Next value: "))
        total = total + m
        if m < minimum:
            minimum = m
        elif m > maximum:
            maximum = m
    average = total / n
    return minimum, maximum, total, average
