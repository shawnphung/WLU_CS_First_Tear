"""
------------------------------------------------------------------------
[Caluclates the sum of all even numbers within a given number]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-29"
------------------------------------------------------------------------
"""
# Import
from functions import sum_even

# Declare variable
num = int(input("Enter a number: "))

# Call function
total = sum_even(num)

# Output
print(f"The sum of all even numbers from 1 to {num} is: {total}")
