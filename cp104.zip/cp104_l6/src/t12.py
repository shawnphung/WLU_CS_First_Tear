"""
------------------------------------------------------------------------
[Calculates the value of a GIC based on user input (principal, time, and rate]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-29"
------------------------------------------------------------------------
"""
# Import
from functions import gic

# Declare variables
value = int(input("Enter the GIC purchase value: $"))
years = int(input("Enter the number of years invested: "))
rate = float(input("Enter the GIC interest rate (%): "))

# Call functions / output
final_value = gic(value, years, rate)
