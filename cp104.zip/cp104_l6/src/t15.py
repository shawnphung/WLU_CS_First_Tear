"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-29"
------------------------------------------------------------------------
"""
# Import
from functions import statistics

# Declare variable
n = int(input("Enter number of values: "))

# Call function
minimum, maximum, total, average = statistics(n)

# Output
print()
print(f"Minimum: {minimum}")
print(f"Maximum: {maximum}")
print(f"Total: {total}")
print(f"Average: {average}")
