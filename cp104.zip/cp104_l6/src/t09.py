"""
------------------------------------------------------------------------
[Outputs n verses of the song "99 Bottles of Beer on the Wall" based on user input]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2021-10-29"
------------------------------------------------------------------------
"""
# Import
from functions import bottles_of_beer

# Declare variable
n = int(input("Enter the amount of verses to print: "))

# Call function / output
print()
bottles_of_beer(n)
