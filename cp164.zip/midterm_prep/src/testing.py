"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-02-14"
-------------------------------------------------------
"""
# Imports
from Sorted_List_array import Sorted_List

source = Sorted_List()
source2 = Sorted_List()

source.insert(11)
source2.insert(22)
source2.insert(33)
source.insert(44)
source2.insert(0)

target = Sorted_List()

target.combine(source, source2)

print()

print("target2")
for value in target:
    print(value)
