"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-02-04"
------------------------------------------------------------------------
"""
# Import
from Queue_array import Queue

# Create queue
q = Queue()

# Insert values into queue
q.insert(4)
q.insert(2)
q.insert(0)

# Call function
target1, target2 = q.split_alt()

# Output
print("Target 1")
while not target1.is_empty():
    print(target1.remove())
print()
print("Target 2")
while not target2.is_empty():
    print(target2.remove())
