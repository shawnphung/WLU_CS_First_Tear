"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-02-04"
------------------------------------------------------------------------
"""
# Imports
from Queue_circular import Queue
from functions import queue_split_alt

# Create empty queue
source = Queue()

# Insert values into queue
source.insert(1)
source.insert(2)
source.insert(3)


target1, target2 = queue_split_alt(source)

# Output
print("Target 1")
while len(target1) > 0:
    print(target1.remove())
print()
print("Target 2")
while not target2.is_empty():
    print(target2.remove())
