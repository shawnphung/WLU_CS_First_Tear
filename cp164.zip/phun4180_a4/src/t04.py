"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-02-04"
------------------------------------------------------------------------
"""
# Imports
from Priority_Queue_array import Priority_Queue
from functions import pq_split_key

# Create queue
source = Priority_Queue()

# Insert values to queue
source.insert(10)
source.insert(20)
source.insert(30)

# Declare key
key = 20

# Call function
target1, target2 = pq_split_key(source, key)

# Output
print(f"Key: {key}")
print()
print("Target 1")
while not target1.is_empty():
    print(target1.remove())
print()
print("Target 2")
while not target2.is_empty():
    print(target2.remove())
