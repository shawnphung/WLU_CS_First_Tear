"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-02-04"
------------------------------------------------------------------------
"""
# Imports
from Queue_circular import Queue

# Create queue
queue = Queue(3)

# Print length and emptiness
print(f"Queue length: {len(queue)}")
print(f"Empty: {queue.is_empty()}")

# Insert value into queue
queue.insert(1)

# Print updated queue length
print(f"Queue length: {len(queue)}")

# Peek
peek = queue.peek()
print(f"Peek: {peek}")

# Remove
remove = queue.remove()
print(f"Remove: {remove}")

# Insert values into queue
queue.insert(21)
queue.insert(69)
queue.insert(420)

# Check for queue fullness
print(f"Queue length: {len(queue)}")
print(f"Full: {queue.is_full()}")
