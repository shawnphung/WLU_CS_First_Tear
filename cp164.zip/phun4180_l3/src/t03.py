"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-29"
------------------------------------------------------------------------
"""
# Imports
from Queue_array import Queue
from utilities import array_to_queue, queue_to_array, queue_test

# Create empty queue
queue = Queue()
source = [14, 69, 420, 80085]

array_to_queue(queue, source)
queue_to_array(queue, source)

print(source)
queue_test(source)
