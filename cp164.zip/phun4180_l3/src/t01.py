"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-29"
------------------------------------------------------------------------
"""
# Import
from Queue_array import Queue

# Create empty queue
queue = Queue()
print(f'Queue length: {len(queue)}')

# Prompt input
value = input("Enter a value: ")

# Call function
queue.insert(value)

# Output
print()
print(f"Queue length: {len(queue)}")
