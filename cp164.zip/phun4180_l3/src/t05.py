"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-29"
------------------------------------------------------------------------
"""
# Import
from Priority_Queue_array import Priority_Queue

# Create empty queue
pq = Priority_Queue()

# Prompt input
value = int(input("Enter a value: "))

pq.insert(value)
print(f"Queue length: {len(pq)}")
print("Removing from queue")
pq.remove()
print(f"Queue length: {len(pq)}")
