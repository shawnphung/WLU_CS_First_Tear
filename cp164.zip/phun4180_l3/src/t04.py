"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-29"
------------------------------------------------------------------------
"""
# Import
from Priority_Queue_array import Priority_Queue

# Create empty queue
pq = Priority_Queue()
print(f"Queue length: {len(pq)}")

# Prompt input
value = int(input("Enter a value: "))

# Call function
pq.insert(value)

# Output
print(pq.peek())
print(f'Queue length: {len(pq)}')
