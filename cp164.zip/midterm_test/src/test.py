"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-02-13"
-------------------------------------------------------
"""
# Imports
from Sorted_List_array import Sorted_List

source1 = Sorted_List()
source2 = Sorted_List()

source1.insert(2)
source1.insert(1)
source2.insert(3)
source2.insert(4)
target = Sorted_List()

target.combine(source1, source2)

for value in target:
    print(value)
