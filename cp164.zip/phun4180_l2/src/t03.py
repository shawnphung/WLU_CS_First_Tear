"""
------------------------------------------------------------------------
[Pops values from stack and push to list]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-22"
------------------------------------------------------------------------
"""
# Import
from Stack_array import Stack
from utilities import stack_to_array

# Declare variables
stack = Stack()
target = []

# Print empty array
print(f"Original list: {target}")

# Push to stack
stack.push([55, 44, 33, 22, 11])

# Call function
stack_to_array(stack, target)

# Output
print(f"New list: {target}")
