"""
------------------------------------------------------------------------
[Test stack_test using foods.txt]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-22"
------------------------------------------------------------------------
"""
# Import
from utilities import stack_test
from Food_utilities import read_foods

# Open file handle
fh = open('foods.txt', 'r')

value = read_foods(fh)

stack_test(value)
