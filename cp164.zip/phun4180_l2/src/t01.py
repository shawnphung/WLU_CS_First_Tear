"""
------------------------------------------------------------------------
[Test Class Stack_array]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-22"
------------------------------------------------------------------------
"""
# Import
from Stack_array import Stack

# Declare variable
stack = Stack()

# Test for empty stack
if stack.is_empty():
    print("Stack is empty.")
else:
    print("Stack is NOT empty.")

# Add 'a' to the stack
stack.push('a')
value = stack.peek()
print()
print(f"Added '{value}' to stack")

# Remove item from stack
value = stack.pop()
print()
print(f"Removed '{value}' from stack")

# Add multiple items to stack
stack.push("Bottom")
stack.push("Top")

# Peek and output
print()
print(stack.peek())
