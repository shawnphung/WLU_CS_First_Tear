"""
------------------------------------------------------------------------
[Test for empty stack, test for pop and peek if stack isn't empty]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-22"
------------------------------------------------------------------------
"""
# Imports
from utilities import stack_test

# Declare variable
source = [1, 2, 3, 4, 5, 6, 7]

# Call function / output
stack_test(source)
