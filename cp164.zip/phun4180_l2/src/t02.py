"""
------------------------------------------------------------------------
[Pushes values from list to stack)
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-22"
------------------------------------------------------------------------
"""
# Import
from Stack_array import Stack
from utilities import array_to_stack

# Define variables
stack = Stack()
source = [1, 2, 3, 4, 5]
print(f"Array: {source}")
# Call function
array_to_stack(stack, source)

# Output
while not stack.is_empty():
    value = stack.pop()
    print(value)
