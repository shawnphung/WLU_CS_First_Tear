"""
------------------------------------------------------------------------
[Creates a list of foods by origin]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-21"
------------------------------------------------------------------------
"""
# Imports
from Food_utilities import by_origin, read_foods
from Food import Food

# Open file handle
fh = open('foods.txt', 'r')

# Declare variables
foods = read_foods(fh)
origin = int(input(f"{Food.origins()}\n""Enter the origin number: "))

# Call function
origins = by_origin(foods, origin)

# Output
print()
for food in origins:
    print(f"{food}\n")

# Close file handle
fh.close()
