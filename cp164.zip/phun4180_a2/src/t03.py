"""
------------------------------------------------------------------------
[Calculates average calorie count for all food items from a specific origin]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-21"
------------------------------------------------------------------------
"""
# Imports
from Food_utilities import calories_by_origin, read_foods
from Food import Food

# Open file handle
fh = open('foods.txt', 'r')

# Declare variables / call function
foods = read_foods(fh)
origin = int(input(f"{Food.origins()}\n""Enter the origin number: "))
avg = calories_by_origin(foods, origin)

# Output
print(f"Average calorie count: {avg}")

# Close file handle
fh.close()
