"""
------------------------------------------------------------------------
[Prints a table of all food items as well as their information]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-21"
------------------------------------------------------------------------
"""
# Imports
from Food_utilities import food_table, read_foods

# Open file handle
fh = open('foods.txt', 'r')
foods = read_foods(fh)

# Call function / output
food_table(foods)

# Close file handle
fh.close()
