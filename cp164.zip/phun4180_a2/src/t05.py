"""
------------------------------------------------------------------------
[Performs a food search based on user's filter settings]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-21"
------------------------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import read_foods, food_search

# Open file handle
fh = open('foods.txt', 'r')
foods = read_foods(fh)

# Prompt user input
origin = int(
    input(f"{Food.origins()}\n""Enter origin number (-1 for all origins): "))
max_cals = int(input("Enter max calorie count (0 for all calorie counts): "))
veg_in = input("Vegetarian? (True or False): ")

# Convert is_veg to boolean
if veg_in.lower() == "true":
    is_veg = True
elif veg_in.lower() == "false":
    is_veg = False

# Call function
result = food_search(foods, origin, max_cals, is_veg)

# Output
for food in result:
    print(f"\n{food}")

# Close file handle
fh.close()
