"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Shawn Phung
ID:      200814180
Email:   phun4180@mylaurier.ca
__updated__ = "2022-03-10"
-------------------------------------------------------
"""
# Imports
from List_linked import List
from Food_utilities import read_foods

fh = open("foods.txt", "r")

foods = read_foods(fh)

new_List = List()
new_List.append(1)
new_List.append(2)
new_List.append(3)

for value in new_List:
    print(value)
