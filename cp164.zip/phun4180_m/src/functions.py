"""
-------------------------------------------------------
Midterm Functions
-------------------------------------------------------
Author:  Shawn Phung
ID:      200814180
Email:   phun4180@mylaurier.ca
__updated__ = "2022-02-14"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack

# Constants
OPERATORS = ('*', '/', '+', '-')


def pq_triage(source, key):
    """
    -------------------------------------------------------
    Removes all values from source that have a priority
    less than key.
    Use: pq_triage(source, key)
    -------------------------------------------------------
    Parameters:
        source - a priority queue (Priority_Queue)
        key - a key value (?)
    Returns‌​‌​‌​​​​:
        None
    -------------------------------------------------------
    """
    for i in range(len(source._values) - 1, -1, -1):
        if source._values[i] < key:
            source._values.pop(i)

    return


def purge(source, key):
    """
    -------------------------------------------------------
    Finds and removes all values in source that match key.
    Use: purge(source, key)
    -------------------------------------------------------
    Parameters:
        source - a List of values (List)
        key - a data element (?)
    Returns‌​‌​‌​​​​:
        None
    -------------------------------------------------------
    """
    for i in range(len(source._values) - 1, -1, -1):
        if source._values[i] == key:
            source._values.pop(i)

    return


def eval_expression(string):
    """
    -------------------------------------------------------
    Evaluates a postfix expression.
    Use: answer = eval_expression(string)
    -------------------------------------------------------
    Parameters:
        string - the space-separted postfix string to evaluate (str)
    Returns‌​‌​‌​​​​:
        answer - the result of evaluating string (float)
    -------------------------------------------------------
    """
    number = Stack()
    operator = Stack()
    answer = None
    i = 0

    while i < len(string):
        if string[i].isnumeric():
            value = string[i]
            number._values.append(value)
        elif string[0] in OPERATORS:
            value = string[i]
            operator._values.push(value)
            if operator._values[0] == "+":
                num2 = number._values.pop()
                num1 = number._values.pop()
                number._values.push(num2 + num1)
            elif operator._values[0] == "-":
                num2 = number._values.pop()
                num1 = number._values.pop()
                number._values.push(num2 - num1)
            elif operator._values[0] == "*":
                num2 = number._values.pop()
                num1 = number._values.pop()
                ans = num2 * num1
                number._values.push(ans)
            elif operator._values[0] == "/":
                num2 = number._values.pop()
                num1 = number._values.pop()
                number._values.push(number._values.pop() /
                                    number._values.pop(-2))
        i += 1
    answer = number._values.pop()

    return answer
