"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-02-05"
------------------------------------------------------------------------
"""
# Import
from List_array import List

# Create list
lst = List()

# Append values
lst.append(100)
lst.append(200)

# Output
print(f"Index 0: {lst[0]}")
print(f"Index 1: {lst[1]}")
print(f"Does index 1 equal 10?: {lst[0] == 10}")
