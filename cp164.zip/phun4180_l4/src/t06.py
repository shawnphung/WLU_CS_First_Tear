"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-02-05"
------------------------------------------------------------------------
"""
# Imports
from List_array import List
from utilities import array_to_list, list_to_array

# Declare variables
lst = List()
source = [17, 38, 69, 420, 21]

# Call array_to_list
array_to_list(lst, source)

print("Array to list: ")
for value in lst:
    print(value)

print()

# Call list_to_array
list_to_array(lst, source)

print("List to array:")
for value in source:
    print(value)
