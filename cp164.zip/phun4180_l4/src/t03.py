"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-02-05"
------------------------------------------------------------------------
"""
# Import
from List_array import List

# Create list
lst = List()

# Insert value
lst.insert(0, 17)

# Print list length
print(f"Length: {len(lst)}")

# Append value
lst.append(38)

# Print list length
print(f"Length: {len(lst)}")

# Remove value
remove = lst.remove(17)
print(f"Removing: {remove}")
