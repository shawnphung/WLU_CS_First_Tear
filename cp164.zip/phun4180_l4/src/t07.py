"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-02-05"
------------------------------------------------------------------------
"""
# Imports
from Food_utilities import read_foods
from utilities import list_test

fh = open('foods.txt', 'r')

source = read_foods(fh)

list_test(source)

fh.close()
