"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-02-05"
------------------------------------------------------------------------
"""
# Import
from List_array import List

# Create list
lst = List()

# Append values
lst.append(-20)
lst.append(-10)
lst.append(10)
lst.append(20)
lst.append(0)

# Index
print(f"Index of 10: {lst.index(10)}")

# Find
print(f"Find 20L {lst.find(20)}")

# Count
print(f"Number of times 0 is in list: {lst.count(0)}")

# Max/Min
print(f"List max: {lst.max()}")
print(f"List min: {lst.min()}")
