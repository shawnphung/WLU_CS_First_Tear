"""
-------------------------------------------------------
[Print Greatest Common Denominator between 2 numbers]
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-02-19"
-------------------------------------------------------
"""
# Imports
from functions import gcd

# Declare variables
m = 9
n = 3

# Call function
ans = gcd(m, n)

# Output
print(f"m = {m}, n = {n}")
print(f"GCD = {ans}")
