"""
-------------------------------------------------------
[Print number of vowels present in a string]
-------------------------------------------------------
Author:  Shawn Phung
ID:      200814180
Email:   phun4180@mylaurier.ca
__updated__ = "2022-02-19"
-------------------------------------------------------
"""
# Imports
from functions import vowel_count

# Declare variable
s = "BEidUvaociw"

# Call function
count = vowel_count(s)

# Output
print(f"String: {s}")
print(f"Vowel count: {count}")
