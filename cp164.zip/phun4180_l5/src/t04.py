"""
-------------------------------------------------------
[Print the answer of a number raised to an exponent]
-------------------------------------------------------
Author:  Shawn Phung
ID:      200814180
Email:   phun4180@mylaurier.ca
__updated__ = "2022-02-19"
-------------------------------------------------------
"""
# Imports
from functions import to_power

# Declare variables
base = int(input("Enter a base number: "))
power = int(input("Enter an exponent: "))

# Call function
ans = to_power(base, power)

# Output
print()
print(f"Answer: {ans}")
