"""
-------------------------------------------------------
[Print whether or not a string is a palindrome]
-------------------------------------------------------
Author:  Shawn Phung
ID:      200814180
Email:   phun4180@mylaurier.ca
__updated__ = "2022-02-19"
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome

# Declare variables
s = "Race, 123 cAr"

# Call function
palindrome = is_palindrome(s)

# Output
print(f"String: '{s}'")

if palindrome is True:
    print("This is a palindrome.")
else:
    print("This is not a palindrome.")
