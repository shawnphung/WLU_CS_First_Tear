"""
-------------------------------------------------------
[Execute and print a simple recursing algorithm]
-------------------------------------------------------
Author:  Shawn Phung
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-02-19"
-------------------------------------------------------
"""
# Imports
from functions import recurse

# Declare variables
x = -1
y = -2

# Call function
ans = recurse(x, y)

# Output
print(f"x = {x}")
print(f"y = {y}")
print(f"ans = {ans}")
