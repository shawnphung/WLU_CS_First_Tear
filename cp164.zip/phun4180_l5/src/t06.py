"""
-------------------------------------------------------
[Take a list and return a new list with only one of each value in the old list]
-------------------------------------------------------
Author:  Shawn Phung
ID:      200814180
Email:   phun4180@mylaurier.ca
__updated__ = "2022-02-19"
-------------------------------------------------------
"""
# Imports
from functions import bag_to_set

# Declare variable
bag = [1, 2, 3, 5, 4, 5, 6, 1, 5, 2, 7]

# Call function
new_set = bag_to_set(bag)

# Output
print(f"Old list: {bag}")
print(f"New list: {new_set}")
