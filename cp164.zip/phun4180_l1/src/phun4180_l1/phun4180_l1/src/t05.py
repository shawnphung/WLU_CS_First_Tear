"""
------------------------------------------------------------------------
[Reads all lines of foods.txt]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-16"
------------------------------------------------------------------------
"""
# Import
from Food_utilities import read_foods

# Open file handle / declare variables
num = 0
fh = open('foods.txt', 'r')

# Read file handle
foods = read_foods(fh)

# Output
for i in foods:
    print(foods[num])
    num += 1
    print()
