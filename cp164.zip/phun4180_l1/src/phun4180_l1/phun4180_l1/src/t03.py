"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-16"
------------------------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import get_food

# Call function
food = get_food()

# Output
print(food)
