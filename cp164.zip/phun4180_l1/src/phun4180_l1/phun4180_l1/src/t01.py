"""
------------------------------------------------------------------------
[Prints a list food origins]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-14"
------------------------------------------------------------------------
"""
# Import
from Food import Food

# Call function / output
s = Food.origins()
print(Food.origins())
