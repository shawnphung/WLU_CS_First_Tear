"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Shawn Phung
ID:      200814180
Email:   phun4180@mylaurier.ca
__updated__ = "2022-02-12"
-------------------------------------------------------
"""
# Imports
from Sorted_List_array import Sorted_List
from Food import Food
from Food_utilities import read_food, read_foods

# Create lists
lst = Sorted_List()
lst2 = Sorted_List()
lst3 = Sorted_List()
lst4 = Sorted_List()

# File handle
fh = open('foods.txt', 'rt')
foods = read_foods(fh)

# Insert
print("Insert...")
shark = Food("Shark Fin Soup", 1, False, 46)
lst.insert(shark)

print()

# Contains
print("Contains...")
print(shark in lst)

print()

# Count
print("Count...")
for value in lst:
    print(f"{value.name} appears in the list {lst.count(value)} times.")

print()

# Find
print("Find...")
burrito = Food("Burrito", 4, False, 200)
lst.insert(burrito)
print(lst.find(burrito))

print()

# Get item
print("__getitem__")
print(lst[1])

print()

# Index
print("Index...")
print(lst.index(burrito))

print()

# Intersection
print("Intersection...")
temp_food = [read_food("Natto|6|True|212"), read_food("BBQ Pork|1|False|920")]
lst2.insert(temp_food[0])
lst2.insert(temp_food[1])
lst2.insert(burrito)
lst3.intersection(lst, lst2)
for value in lst3:
    print(value.name)

print()

# Is identical
print("Are lists 3 and 4 identical?")
lst4.insert(burrito)
print(lst3.is_identical(lst4))

print()

# Max/Min
print("Max...")
value = lst2.max()
print(value.name)
print()
print("Min...")
value2 = lst2.min()
print(value2.name)

print()

# Peek
print("Peek...")
value = lst2.peek()
print(value.name)

print()

# Remove
print("Remove...")
lst2.remove(temp_food[1])
for value in lst2:
    print(value.name)

print()

# Remove front
print("Remove front...")
lst2.remove_front()
for value in lst2:
    print(value.name)

print()

# Remove many
print("Remove many...")
lst4.insert(temp_food[0])
lst4.insert(temp_food[1])
lst4.remove_many(temp_food[0])
for value in lst4:
    print(value.name)

print()

# Split
print("Split...")
lst4.insert(shark)
lst4.insert(temp_food[0])
target1, target2 = lst4.split()
print("Target 1")
for value in target1:
    print(value.name)
print()
print("Target 2")
for value in target2:
    print(value.name)

print()

# Split_alt
print("Split_alt...")
lst4.insert(temp_food[1])
lst4.insert(burrito)
lst4.insert(shark)
lst4.insert(temp_food[0])
target1, target2 = lst4.split_alt()
print("Target 1")
for value in target1:
    print(value.name)
print()
print("Target 2")
for value in target2:
    print(value.name)

print()

# Split key
print("Split key...")
lst4.insert(temp_food[1])
lst4.insert(burrito)
lst4.insert(shark)
lst4.insert(temp_food[0])
target1, target2 = lst4.split_key(burrito)
print("Target 1")
for value in target1:
    print(value.name)
print()
print("Target 2")
for value in target2:
    print(value.name)

print()

# Union
print("Union...")
lst4.union(lst, lst2)
for value in lst4:
    print(value.name)
