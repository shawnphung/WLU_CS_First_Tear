"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Shawn Phung
ID:      200814180
Email:   phun4180@mylaurier.ca
__updated__ = "2022-02-12"
-------------------------------------------------------
"""
# Imports
from List_array import List
from Food_utilities import read_food, read_foods
from Food import Food

# Declare variables
i = 0

# File handle
fh = open('foods.txt', 'rt')
foods = read_foods(fh)

# Create list
lst = List()

# Append
print("Append...")
shark = Food("Shark Fin Soup", 1, False, 46)
lst.append(shark)

# Checking for additional shark fine soup item in text file
for value in lst:
    print(f"{value.name} appears {lst.count(value)} times.")

print()

# Clean
lst.append(shark)
print("Clean...")
burrito = Food("Burrito", 4, False, 200)
lst.append(burrito)
lst.clean()
for value in lst:
    print(f"{value.name} appears {lst.count(value)} times.")

print()

# Combine
print("Combine...")
temp_food = [read_food("Natto|6|True|212"), read_food("BBQ Pork|1|False|920")]
# Create empty lists
lst2 = List()
lst3 = List()
# Append food items to lst2
while i < len(temp_food):
    lst2.append(temp_food[i])
    i += 1
# Test combine
lst3.combine(lst, lst2)
for value in lst3:
    print(value.name)

print()

# Get item
print("__getitem__")
print(f'''3rd index:
{lst3[3]}''')

print()

# Intersect
print("Intersection...")
lst2.append(temp_food[0])
# Create list for POI
lst4 = List()
lst4.intersection(lst2, lst3)
print("Lists 2 and 3 intersect at: ")
for value in lst4:
    print(value.name)

print()

# Is identical
print("Are lists 1 and 2 identical?")
print(lst.is_identical(lst2))

print()

# Prepend
print("Prepend...")
lst4.prepend(temp_food[1])
for value in lst4:
    print(value.name)

print()

# Remove front
print("Remove front...")
lst4.remove_front()
for value in lst4:
    print(value.name)

print()

# Remove many
print("Remove many...")
lst4.append(temp_food[0])
lst4.append(temp_food[1])
lst4.remove_many(temp_food[0])
for value in lst4:
    print(value.name)

print()

# Split
print("Split...")
target1, target2 = lst3.split()

print("List 1:")
for value in target1:
    print(value.name)
print()

print("List 2: ")
for value in target2:
    print(value.name)

print()

# Split_alt
print("Split_alt...")
lst2.append(temp_food[1])
lst2.append(temp_food[0])
lst2.append(temp_food[1])
target3, target4 = lst2.split_alt()

print("List 1:")
for value in target3:
    print(value.name)
print()

print("List 2:")
for value in target4:
    print(value.name)

print()

# Union
print("Union...")
lst3.union(target1, target2)
for value in lst3:
    print(value.name)
