"""
------------------------------------------------------------------------
[Outputs a list with at most one of each value]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-10"
------------------------------------------------------------------------
"""
# Import
from functions import clean_list

# Ask user x number of values/empty list
num = int(input("Enter number of values: "))
values = []

# Ask for values
for i in range(num):
    inp = int(input("Enter a number: "))
    values.append(inp)

# Call function
clean_list(values)
