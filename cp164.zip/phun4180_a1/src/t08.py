"""
------------------------------------------------------------------------
[Determines the smallest, largest, total, and average values of a matrix]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-11"
------------------------------------------------------------------------
"""
# Import
from functions import matrix_stats

# Declare matrix
a = [1, 2, 3, 4, 5], [6, 7, 8, 9, 0], [21, 69, 420, 17, 38]

# Call function
small, large, total, average = matrix_stats(a)

# Output
print(f"Matrix: {a}")
print()
print(f"Largest: {large}")
print(f"Smallest: {small}")
print(f"Total: {total}")
print(f"Average: {average:.2f}")
