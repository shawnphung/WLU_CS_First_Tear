"""
------------------------------------------------------------------------
[Determines if a string is a palindrome]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-11"
------------------------------------------------------------------------
"""
# Import
from functions import is_palindrome

# Declare variable
s = input("Enter a palindrome: ")

# Call function
palindrome = is_palindrome(s)

# Output
print(palindrome)
