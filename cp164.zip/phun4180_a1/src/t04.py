"""
------------------------------------------------------------------------
[Determines whether or not input year is a leap year]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-11"
------------------------------------------------------------------------
"""
# Import
from functions import is_leap_year

# Declare variable
year = int(input("Enter a year: "))

# Call function
leap_year = is_leap_year(year)

# Output
print()
if leap_year is True:
    print(f"{year} is a leap year.")
else:
    print(f"{year} is not a leap year.")
