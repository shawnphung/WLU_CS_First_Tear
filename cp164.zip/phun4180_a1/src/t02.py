"""
------------------------------------------------------------------------
[Removes all vowels from a string]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-11"
------------------------------------------------------------------------
"""
# Import
from functions import dsmvwl

# Declare variable
s = input("Enter a sentence: ")

# Call function
out = dsmvwl(s)

# Output
print()
print(f"Sentence: {s}")
print(f"Disemvowelled: {out}")
