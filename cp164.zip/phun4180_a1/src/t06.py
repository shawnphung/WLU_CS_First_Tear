"""
------------------------------------------------------------------------
[Calculates the largest difference between two adjacent values in a list]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-11"
------------------------------------------------------------------------
"""
# Import
from functions import max_diff

# Declare variables
num = int(input("Enter number of values: "))

# Create list
a = []
for i in range(num):
    val = int(input("Enter a number: "))
    a.append(val)

# Call function
md = max_diff(a)

# Output
print()
print(f"Values: {a}")
print(f"Max difference: {md}")
