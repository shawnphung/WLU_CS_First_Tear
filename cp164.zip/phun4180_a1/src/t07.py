"""
------------------------------------------------------------------------
[Transpose a matrix]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-11"
------------------------------------------------------------------------
"""
# Import
from functions import matrix_transpose

# Declare list
a = [0, 2, 4, 6, 8], [1, 3, 5, 7, 9]

# Call function
b = matrix_transpose(a)

# Output
print(f"Original: {a}")
print(f"Transposed: {b}")
