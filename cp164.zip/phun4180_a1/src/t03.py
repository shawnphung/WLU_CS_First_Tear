"""
------------------------------------------------------------------------
[Analyzes the contents (characters) of a file]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-11"
------------------------------------------------------------------------
"""
# Import
from functions import file_analyze

# Declare variable
fv = open("read_file.txt", "r", encoding="utf-8")

# Call function
u, l, d, w, r = file_analyze(fv)

# Output
print(f"Upper case: {u}")
print(f"Lower case: {l}")
print(f"Digits: {d}")
print(f"Whitespace: {w}")
print(f"Remaining: {r}")
