"""
------------------------------------------------------------------------
[Prints the user's input in Pig_Latin]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-12"
------------------------------------------------------------------------
"""
# Import
from functions import pig_latin

# Declare variable
word = input("Enter a word: ")

# Call function
pl = pig_latin(word)

# Output
print(f"Pig-Latin: {pl}")
