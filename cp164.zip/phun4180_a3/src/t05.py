"""
------------------------------------------------------------------------
[Returns if a string is a palindrome]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
s = "2022-01-28"
------------------------------------------------------------------------
"""
# Imports
from functions import is_palindrome_stack

# Declare variable
string = '1race,car!'

# Call function
palindrome = is_palindrome_stack(string)

# Output
print(f"String: {string}")
print(palindrome)
