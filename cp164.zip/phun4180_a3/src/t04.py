"""
------------------------------------------------------------------------
[Returns a reversed stack]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-28"
------------------------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from utilities import array_to_stack

# Declare stack
source = Stack()
array_to_stack(source, [1, 2, 3, 4, ])

# Call function
source.reverse()

# Output
print("Reversed stack:")
while not source.is_empty():
    print(source.pop())
