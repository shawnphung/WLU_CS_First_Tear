"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-28"
------------------------------------------------------------------------
"""
# Import
from functions import reroute

# Declare variables
opstring = input("Enter opstring: ")
values_in = [1, 2, 3, 4]

# Call function
values_out = reroute(opstring, values_in)

# Output
print(f"Original list: {values_in}")
print(f"Rerouted list: {values_out}")
