"""
------------------------------------------------------------------------
[Returns a reversed stack]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-28"
------------------------------------------------------------------------
"""
# Import
from functions import stack_reverse
from Stack_array import Stack
from utilities import array_to_stack

# Declare variable
source = Stack()
array_to_stack(source, [1, 2, 3, 4])

# Call function
stack_reverse(source)

# Output reverse
print("Reversed stack:")
while not source.is_empty():
    print(source.pop())
