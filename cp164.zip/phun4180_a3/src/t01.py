"""
------------------------------------------------------------------------
[Combines two source stacks into a target stack]
------------------------------------------------------------------------
Author: Shawn Quan Phung
ID:     200814180
Email:  phun4180@mylaurier.ca
__updated__ = "2022-01-28"
------------------------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from utilities import array_to_stack
from functions import stack_combine

# Create empty source stacks
source1 = Stack()
source2 = Stack()

# Push to source stacks
array_to_stack(source1, [5, 8, 12, 8])
array_to_stack(source2, [3, 6, 1, 7, 9, 14])

# Call function
target = stack_combine(source1, source2)

# Output
print("Combined stack: ")
while not target.is_empty():
    value = target.pop()
    print(value)
